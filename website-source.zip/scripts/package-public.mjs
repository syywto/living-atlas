import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const site=JSON.parse(await fs.readFile(path.join(root,'data/site.json'),'utf8'));
const output=path.join(root,'发布文件');
const stamp=new Date().toISOString().replace(/[:.]/g,'-');
const target=path.join(output,'living-atlas-public-'+stamp);
await fs.mkdir(target,{recursive:true});
const copy=async name=>fs.cp(path.join(root,name),path.join(target,name),{recursive:true});
for(const name of ['public','lib','tests','package.json','server.mjs','启动网站.cmd','导出展示版.cmd'])await copy(name);
await fs.mkdir(path.join(target,'scripts'));
for(const name of ['export.mjs','start-local.mjs','package-public.mjs'])await copy('scripts/'+name);
// Always publish the current snapshot; never copy old exports or private runtime data.
await fs.writeFile(path.join(target,'public','seed.json'),JSON.stringify({...site,revision:0},null,2)+'\n');
const display=['index.html','styles.css','app.js','content-search.mjs','map-learning.mjs','floating-atlas.mjs','floating-atlas.css','virtual-map.mjs','virtual-map.css','studio.js','studio.css','reader.css','assets'];
await fs.mkdir(path.join(target,'docs'));
for(const name of display)await fs.cp(path.join(target,'public',name),path.join(target,'docs',name),{recursive:true});
await fs.writeFile(path.join(target,'docs','data.json'),JSON.stringify(site,null,2)+'\n');
await fs.writeFile(path.join(target,'docs','.nojekyll'),'');
const blocks=[...site.nodes.flatMap(n=>[...n.blocks,...(n.design?.objects||[])]),...Object.values(site.layouts||{}).flatMap(l=>l.objects||[])];
const assets=[...new Set(blocks.filter(b=>['image','file'].includes(b.type)&&/^\/uploads\/[a-f0-9-]+\.[a-z0-9]+$/.test(b.url)).map(b=>b.url.slice(1)))];
for(const asset of assets){await fs.mkdir(path.dirname(path.join(target,asset)),{recursive:true});await fs.mkdir(path.dirname(path.join(target,'docs',asset)),{recursive:true});await fs.copyFile(path.join(root,asset),path.join(target,asset));await fs.copyFile(path.join(root,asset),path.join(target,'docs',asset));}
const ignore=['node_modules/','.runtime/','.test-runtime*/','.env','.env.*','data/','发布文件/','*.log','.DS_Store','Thumbs.db','uploads/*',...assets.map(name=>'!'+name),''];
await fs.writeFile(path.join(target,'.gitignore'),ignore.join('\n'));
const description=`# 三张活地图 · 多模态大模型的视觉理解与推理

围绕图表问答，连接领域知识、研究生态与可核查的分析过程。当前版本 ${site.meta.version}，包含 ${site.nodes.length} 个条目、${site.nodes.reduce((sum,n)=>sum+n.links.length,0)} 条有理由的关联。

## 在线浏览

网站从本仓库的 docs 目录发布。可浏览三张地图、关联浮标、全文文档、来源、图片和教学练习。图表为自制教学数据，不是模型性能实验。成员贡献及真实互评尚未填录。

这是静态展示版，在线管理员编辑、服务端反馈与生成式 AI 不运行。管理员编辑在自己的电脑上完成，再导出并发布新版。

## 本地修改

1. 安装 Node.js 22 或更高版本，无需安装第三方依赖。
2. 下载并解压完整项目，双击“启动网站.cmd”。
3. 初次运行时自行设置管理员密码，在网站内编辑并保存。
4. 双击“导出展示版.cmd”，更新 docs 目录。
5. 提交并推送新的 docs 文件，等待 GitHub Pages 发布完成。

也可以运行 node server.mjs 启动，运行 node scripts/export.mjs 导出。默认终端启动地址为 http://127.0.0.1:3000；Windows 启动器优先使用 3001，以实际提示为准。

## 文件说明

- public：网页与当前初始内容。
- docs：可直接发布的展示版及明确引用的教学附件。
- server.mjs、lib：本地验证、保存与编辑所需的服务代码。
- scripts：启动、导出与安全打包工具。
- tests：使用隔离数据的功能检查，可运行 node --test tests/*.test.mjs。
- uploads：本内容明确引用的公开教学图片和 CSV/TXT 附件。

密码、密钥、运行记录、实际反馈及修改历史不包含在本仓库。公开代码中的密码只出现在隔离测试用例，不是本站管理员密码。下载本项目不会获得原管理员权限，首次本地运行需要自行初始化。

## 发布设置

仓库 Settings → Pages → Deploy from a branch → main → /docs。

页面资料的适用范围、出处和待核实事项以各条目说明为准。本校课程关联、真实模型实践与 AI 能力仍需真实材料，不以页面完整代替完成全部课程要求。
`;
await fs.writeFile(path.join(target,'README.md'),description);
const files=[];async function walk(dir){for(const entry of await fs.readdir(dir,{withFileTypes:true})){const full=path.join(dir,entry.name);if(entry.isDirectory())await walk(full);else files.push(full);}}
await walk(target);
// Compare without displaying any credential values.
let credential;try{credential=JSON.parse(await fs.readFile(path.join(root,'.runtime','admin.json'),'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;}
const forbidden=[credential?.hash,credential?.salt,credential?.scryptSalt].filter(Boolean);
const manifest=[];
for(const file of files){const rel=path.relative(target,file).replaceAll('\\','/');if(/(^|\/)(\.runtime|data|\.env|node_modules|\.git)(\/|$)/.test(rel))throw Error('Private path in package: '+rel);const bytes=await fs.readFile(file);if(forbidden.some(value=>bytes.includes(Buffer.from(value))))throw Error('Private credential value in package: '+rel);manifest.push({file:rel,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});}
await fs.writeFile(path.join(output,'latest-package.json'),JSON.stringify({directory:target,files:manifest,assets:assets.length,version:site.meta.version},null,2));
console.log(JSON.stringify({directory:target,files:files.length,bytes:manifest.reduce((sum,f)=>sum+f.bytes,0),teachingAssets:assets.length,version:site.meta.version,credentialLeak:false}));
