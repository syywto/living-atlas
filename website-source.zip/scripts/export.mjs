import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const target=path.join(root,'docs');
let site;
try{site=JSON.parse(await fs.readFile(path.join(root,'data','site.json'),'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;site=JSON.parse(await fs.readFile(path.join(root,'public','seed.json'),'utf8'));}
await fs.mkdir(target,{recursive:true});
for(const name of ['index.html','styles.css','app.js','content-search.mjs','map-learning.mjs','floating-atlas.mjs','floating-atlas.css','virtual-map.mjs','virtual-map.css','studio.js','studio.css','reader.css','assets'])await fs.cp(path.join(root,'public',name),path.join(target,name),{recursive:true});
await fs.writeFile(path.join(target,'data.json'),JSON.stringify(site,null,2));
await fs.writeFile(path.join(target,'.nojekyll'),'');
let count=0;
const attachments=[...site.nodes.flatMap(n=>[...n.blocks,...(n.design?.objects||[])]),...Object.values(site.layouts||{}).flatMap(l=>l.objects||[])];
for(const block of attachments){if(['image','file'].includes(block.type)&&/^\/uploads\/[a-f0-9-]+\.[a-z0-9]+$/.test(block.url)){await fs.mkdir(path.join(target,'uploads'),{recursive:true});await fs.copyFile(path.join(root,block.url.slice(1)),path.join(target,block.url.slice(1)));count++;}}
console.log(`已导出静态展示版到 docs/（${site.nodes.length} 个条目、${count} 个附件）。\n不包含密码、密钥和反馈。导出内容及附件将公开，请上传前核查。\nGitHub Pages：Settings → Pages → Deploy from a branch → main /docs。`);
