import fs from 'node:fs';
import path from 'node:path';
import net from 'node:net';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
process.chdir(root);
const runtime=path.join(root,'.runtime');
fs.mkdirSync(runtime,{recursive:true});
const logFile=path.join(runtime,'startup.log');
fs.writeFileSync(logFile,`Living Atlas local launcher\n${new Date().toISOString()}\nNode: ${process.version}\n`);
const log=message=>{console.log(message);fs.appendFileSync(logFile,message+'\n');};
let child;
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));

async function isAtlas(port){
  try{
    const response=await fetch(`http://127.0.0.1:${port}/api/state`,{signal:AbortSignal.timeout(900)});
    if(!response.ok)return false;
    const data=await response.json();
    return data.mode==='server' && !!data.site?.meta && Array.isArray(data.site?.nodes) && Number.isInteger(data.site?.revision);
  }catch{return false;}
}
function available(port){
  return new Promise((resolve,reject)=>{
    const probe=net.createServer();
    probe.once('error',error=>error.code==='EADDRINUSE'?resolve(false):reject(error));
    probe.listen(port,'127.0.0.1',()=>probe.close(()=>resolve(true)));
  });
}
async function openBrowser(url){
  if(process.argv.includes('--no-browser'))return false;
  // Launch the installed browser directly: Explorer can accept a URL without
  // creating a browser window when Windows' URL association is unavailable.
  const locations=[process.env['ProgramFiles(x86)'],process.env.ProgramFiles,process.env.LOCALAPPDATA].filter(Boolean);
  const browsers=[...locations.map(base=>({name:'Microsoft Edge',exe:path.join(base,'Microsoft','Edge','Application','msedge.exe')})),...locations.map(base=>({name:'Google Chrome',exe:path.join(base,'Google','Chrome','Application','chrome.exe')}))];
  for(const browser of browsers){
    if(!fs.existsSync(browser.exe))continue;
    try{
      await new Promise((resolve,reject)=>{
        const app=spawn(browser.exe,['--new-window',url],{stdio:'ignore',windowsHide:false,detached:true});
        let timer;
        app.once('error',error=>{clearTimeout(timer);reject(error);});
        app.once('spawn',()=>{app.unref();timer=setTimeout(resolve,1000);});
        app.once('exit',code=>{clearTimeout(timer);if(code && code!==0)reject(new Error('浏览器退出码 '+code));else resolve();});
      });
      log('已请求 '+browser.name+' 打开：'+url);return true;
    }catch(error){log(browser.name+' 启动失败：'+error.message);}
  }
  log('未能自动打开浏览器。网站服务保持运行，请复制本地预览地址到 Edge。');
  return false;
}
async function start(){
  if(Number(process.versions.node.split('.')[0])<22)throw new Error('需要 Node.js 22 或更高版本。请从 https://nodejs.org 安装后重试。');
  if(!fs.existsSync(path.join(root,'server.mjs')))throw new Error('缺少 server.mjs，请从完整的项目文件夹启动。');
  if(process.argv.includes('--check')){log('启动环境检查通过。');log('Node.js：'+process.execPath);log('项目目录：'+root);return;}
  try{process.loadEnvFile(path.join(root,'.env'));}catch(error){if(error.code!=='ENOENT')throw error;}
  const preferred=Number(process.env.PORT||3001);
  if(!Number.isInteger(preferred)||preferred<1||preferred>65535)throw new Error('PORT 必须是 1–65535 之间的端口号。');
  const ports=[...new Set([preferred,3001,3000,3002])];
  for(const port of ports){
    if(await isAtlas(port)){
      const url=`http://127.0.0.1:${port}/`;
      log('网站已经在本机运行，无需重复启动。');log('本地预览：'+url);
      log('即将打开浏览器。关闭这个检查窗口不会停止已有服务。');
      await openBrowser(url);return;
    }
  }
  let port;
  for(const candidate of ports){if(await available(candidate)){port=candidate;break;}}
  if(!port)throw new Error('可用的本地端口均被占用，请关闭旧的网站终端，或在 .env 中指定其他 PORT。');
  log('正在启动网站，请稍候…');
  child=spawn(process.execPath,[path.join(root,'server.mjs')],{cwd:root,env:{...process.env,HOST:'127.0.0.1',PORT:String(port)},stdio:['inherit','pipe','pipe'],windowsHide:true});
  let spawnError,exited=false,exitCode;
  child.once('error',error=>{spawnError=error;});
  child.once('exit',code=>{exited=true;exitCode=code;});
  child.stdout.on('data',data=>{process.stdout.write(data);fs.appendFileSync(logFile,data);});
  child.stderr.on('data',data=>{process.stderr.write(data);fs.appendFileSync(logFile,data);});
  let ready=false;
  for(let i=0;i<60;i++){
    if(spawnError)throw spawnError;
    if(exited)throw new Error('网站进程启动失败，详细信息见上方及 .runtime/startup.log。');
    if(await isAtlas(port)){ready=true;break;}
    await delay(200);
  }
  if(!ready){child.kill();throw new Error('启动等待超时，请查看 .runtime/startup.log。');}
  const url=`http://127.0.0.1:${port}/`;
  log('\n本地预览：'+url);log('请保留此窗口。关闭此窗口或按 Ctrl+C 会停止本次启动的网站。');
  log('首次使用：右上角齿轮 → 管理员入口 → 设置密码。');
  await openBrowser(url);
  if(!exited)await new Promise(resolve=>child.once('exit',resolve));
  process.exitCode=exitCode||0;
}
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>{child?.kill();process.exit(0);});
start().catch(error=>{child?.kill();log('\n启动失败：'+error.message);log('错误日志：'+logFile);process.exitCode=1;});
