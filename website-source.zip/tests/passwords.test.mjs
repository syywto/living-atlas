import {test} from 'node:test';
import assert from 'node:assert/strict';
import {pbkdf2Sync,randomBytes,scryptSync} from 'node:crypto';
import {createPasswordCredential,upgradePasswordCredential,verifyPassword,PASSWORD_ITERATIONS} from '../lib/passwords.mjs';

test('password derivation retains scrypt and applies exactly 300000 PBKDF2 iterations',async()=>{
  const password='test-only-地图-長密碼-🗺️';
  const first=await createPasswordCredential(password),second=await createPasswordCredential(password);
  assert.equal(first.algorithm,'scrypt-pbkdf2-sha256');assert.equal(first.version,2);
  assert.equal(first.iterations,300000);assert.equal(PASSWORD_ITERATIONS,300000);
  assert.notEqual(first.scryptSalt,second.scryptSalt);assert.notEqual(first.salt,second.salt);assert.notEqual(first.hash,second.hash);
  const intermediate=scryptSync(password,first.scryptSalt,64);
  const expected=pbkdf2Sync(intermediate,Buffer.from(first.salt,'hex'),300000,32,'sha256').toString('hex');
  assert.equal(first.hash,expected);
  assert.equal(await verifyPassword(password,first),true);
  assert.equal(await verifyPassword('incorrect',first),false);
  assert(!JSON.stringify(first).includes(password));
});

test('legacy credentials migrate without plaintext, preserve the password and do not rehash again',async()=>{
  const password='test-only-legacy-long-password',salt=randomBytes(24).toString('hex');
  const legacy={salt,hash:scryptSync(password,salt,64).toString('hex')};
  const saved=structuredClone(legacy),current=await upgradePasswordCredential(legacy);
  assert.deepEqual(legacy,saved,'migration must not mutate the original record');
  assert.equal(current.scryptSalt,legacy.salt);assert.equal(current.iterations,300000);
  assert.notEqual(current.hash,legacy.hash,'only the new wrapped hash is persisted');
  assert.equal(await verifyPassword(password,JSON.parse(JSON.stringify(current))),true);
  assert.equal(await verifyPassword('wrong password',current),false);
  assert.strictEqual(await upgradePasswordCredential(current),current,'restarts must not wrap the hash repeatedly');
});

test('malformed or downgraded credential metadata is rejected',async()=>{
  const current=await createPasswordCredential('test-only-validation-password');
  for(const record of [null,{}, {...current,iterations:1},{...current,version:99},{...current,algorithm:'sha256'},{...current,hash:'ab'},{...current,salt:'not-hex'}]){
    assert.equal(await verifyPassword('test-only-validation-password',record),false);
    await assert.rejects(upgradePasswordCredential(record),/格式不受支持/);
  }
  await assert.rejects(upgradePasswordCredential({salt:'a'.repeat(48),hash:'b'.repeat(128),version:99}),/格式不受支持/);
});
