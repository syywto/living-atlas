import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {buildAtlas,createHoverIntent,HOVER_DELAY} from '../public/floating-atlas.mjs';

test('floating map preserves directed evidence while merging reciprocal lines',()=>{
  const nodes=[{id:'a',map:'domain',links:[{id:'b',reason:'adopts'},{id:'b',reason:'duplicate'},{id:'missing',reason:'broken'},{id:'a',reason:'self'}]},{id:'b',map:'ecology',links:[{id:'a',reason:'supports'}]},{id:'c',map:'cognition',links:[]}];
  const result=buildAtlas(nodes);
  assert.equal(result.points.size,3);assert.equal(result.hubs.length,3);assert.equal(result.edges.length,1);assert.equal(result.relationCount,2);
  assert.deepEqual(result.edges[0].relations,[{from:'a',to:'b',reason:'adopts'},{from:'b',to:'a',reason:'supports'}]);
});

test('every saved article has a positioned buoy and every relationship resolves',async()=>{
  const site=JSON.parse(await fs.readFile(new URL('../public/seed.json',import.meta.url),'utf8')),result=buildAtlas(site.nodes);
  assert.equal(result.points.size,site.nodes.length);assert.equal(result.relationCount,site.nodes.reduce((s,n)=>s+n.links.length,0));
  for(const p of result.points.values()){assert(Number.isFinite(p.x)&&Number.isFinite(p.y));assert(p.x>70&&p.x<result.width-70&&p.y>50&&p.y<result.height-50);}
  for(const hub of result.hubs)assert.equal(hub.nodes.length,site.nodes.filter(n=>n.map===hub.id).length);
});

function clock(){let now=0,next=1;const jobs=new Map();return {setTimeout(fn,ms){const id=next++;jobs.set(id,{fn,at:now+ms});return id;},clearTimeout(id){jobs.delete(id);},tick(ms){const end=now+ms;while(true){const first=[...jobs.entries()].filter(([,j])=>j.at<=end).sort((a,b)=>a[1].at-b[1].at)[0];if(!first)break;now=first[1].at;jobs.delete(first[0]);first[1].fn();}now=end;},get pending(){return jobs.size;}};}
test('hover preview waits 800 ms, cancels fast passes and survives re-entry',()=>{
  const timers=clock(),shown=[],hidden=[],highlighted=[];
  const intent=createHoverIntent({show:id=>shown.push(id),hide:()=>hidden.push(true),highlight:id=>highlighted.push(id)},timers);
  assert.equal(HOVER_DELAY,800);intent.enter('a');timers.tick(799);assert.equal(shown.length,0);timers.tick(1);assert.deepEqual(shown,['a']);
  intent.enter('b');timers.tick(500);intent.leave();timers.tick(80);intent.enter('b');timers.tick(799);assert.deepEqual(shown,['a']);timers.tick(1);assert.deepEqual(shown,['a','b']);
  intent.enter('c');timers.tick(100);intent.leave();timers.tick(1000);assert.deepEqual(shown,['a','b']);assert.equal(highlighted.at(-1),null);
  intent.enter('d',true);assert.equal(shown.at(-1),'d');intent.enter('e');intent.destroy();timers.tick(1000);assert.equal(shown.at(-1),'d');assert.equal(timers.pending,0);
});
