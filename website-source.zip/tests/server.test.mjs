import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import net from 'node:net';
import {randomBytes,scryptSync} from 'node:crypto';
const dir=await fs.mkdtemp(path.join(os.tmpdir(),'living-atlas-test-'));
const seed=JSON.parse(await fs.readFile(new URL('../public/seed.json',import.meta.url),'utf8'));
let server,base,cookie,revision,site;
const password='test-only-'+Math.random().toString(36)+'-long-password';
async function call(route,method='GET',data,admin=false,headers={}){const r=await fetch(base+route,{method,headers:{...(data?{'Content-Type':'application/json'}:{}),...(admin?{Cookie:cookie}:{}),...headers},body:data?JSON.stringify(data):undefined});return {r,data:await r.json()};}
before(async()=>{const probe=net.createServer();probe.listen(0,'127.0.0.1');await once(probe,'listening');const port=probe.address().port;await new Promise(r=>probe.close(r));base='http://127.0.0.1:'+port;server=spawn(process.execPath,['server.mjs'],{env:{...process.env,PORT:String(port),HOST:'127.0.0.1',DATA_DIR:path.join(dir,'data'),RUNTIME_DIR:path.join(dir,'private'),UPLOAD_DIR:path.join(dir,'uploads'),PUBLIC_ORIGIN:'',ADMIN_PASSWORD:'',AI_API_KEY:'',AI_BASE_URL:'',AI_MODEL:''},stdio:['ignore','pipe','pipe']});await new Promise((resolve,reject)=>{server.stdout.once('data',resolve);server.once('error',reject);server.once('exit',code=>reject(new Error('Server exited '+code)));});});
after(async()=>{if(server){const exit=once(server,'exit');server.kill();await exit;}await fs.rm(dir,{recursive:true,force:true});});
test('auth, persistence, permissions, structured documents and feedback',async()=>{
  let result=await call('/api/state');assert.equal(result.data.setupRequired,true);site=result.data.site;revision=site.revision;
  assert.deepEqual(site.nodes.map(n=>n.id),seed.nodes.map(n=>n.id),'server loads the complete current starter map');
  for(const n of site.nodes)for(const link of n.links)assert(site.nodes.some(t=>t.id===link.id),'every relationship resolves');
  result=await call('/api/site','PUT',site);assert.equal(result.r.status,401);
  result=await call('/api/setup','POST',{password:'short'});assert.equal(result.r.status,400);
  result=await call('/api/setup','POST',{password});assert.equal(result.r.status,200);
  const storedCredential=JSON.parse(await fs.readFile(path.join(dir,'private/admin.json'),'utf8'));
  assert.equal(storedCredential.version,2);assert.equal(storedCredential.iterations,300000);
  assert.equal(storedCredential.algorithm,'scrypt-pbkdf2-sha256');
  assert(!JSON.stringify(storedCredential).includes(password));
  result=await call('/api/setup','POST',{password});assert.equal(result.r.status,409);
  result=await call('/api/login','POST',{password:'incorrect'});assert.equal(result.r.status,401);
  result=await call('/api/login','POST',{password});assert.equal(result.r.status,200);cookie=result.r.headers.get('set-cookie').split(';')[0];assert.match(result.r.headers.get('set-cookie'),/HttpOnly/);assert.match(result.r.headers.get('set-cookie'),/SameSite=Strict/);
  result=await call('/api/state','GET',null,true);assert.equal(result.data.admin,true);
  const modified=structuredClone(site);modified.nodes[0].blocks=[{type:'paragraph',runs:[{text:'<script>alert(1)</script> 测试',bold:true,color:'#0071e3'}]},{type:'table',rows:[['指标','值'],['测试','3']]},{type:'chart',title:'测试',values:[{label:'甲',value:3}]}];
  result=await call('/api/site','PUT',modified,true);assert.equal(result.r.status,200);assert.equal(result.data.site.revision,revision+1);site=result.data.site;
  const disk=JSON.parse(await fs.readFile(path.join(dir,'data/site.json'),'utf8'));assert.equal(disk.nodes[0].blocks[0].runs[0].text,'<script>alert(1)</script> 测试');assert.equal((await fs.readdir(path.join(dir,'data/history'))).length,1);
  const designed=structuredClone(site);designed.layouts={home:{height:1200,objects:[{id:'image-1',type:'image',url:'/uploads/12345678-abcd.png',name:'test.png',x:200,y:100,w:400,h:300,rotation:25,crop:{left:.1,right:0,top:0,bottom:0},feather:12}]}};designed.pageTexts={home:{title:{runs:[{text:'编辑后的标题',font:'SimSun',size:48,gradient:'ocean'}],align:'center'}}};designed.nodes[0].design={height:800,objects:[{id:'text-1',type:'text',runs:[{text:'文档正文',size:20}],x:50,y:50,w:800,h:100}]};
  designed.layouts.home.objects.push({id:'group-1',type:'section',title:'新资料板块',runs:[{text:'板块正文'}]});designed.layouts.home.flow={root:['base:hero','object:group-1'],'section:group-1':['object:image-1']};
  result=await call('/api/site','PUT',designed,true);assert.equal(result.r.status,200);site=result.data.site;assert.equal(site.layouts.home.objects[0].rotation,25);assert.equal(site.pageTexts.home.title.runs[0].gradient,'ocean');assert.equal(site.nodes[0].design.objects[0].runs[0].text,'文档正文');
  const persisted=(await call('/api/state')).data.site;assert.deepEqual(persisted.layouts.home.flow.root,['base:hero','object:group-1']);assert.deepEqual(persisted.layouts.home.flow['section:group-1'],['object:image-1']);assert.equal(persisted.layouts.home.objects[1].title,'新资料板块');assert.deepEqual(JSON.parse(await fs.readFile(path.join(dir,'data/site.json'),'utf8')).layouts.home.flow,persisted.layouts.home.flow);
  result=await call('/api/site','PUT',modified,true);assert.equal(result.r.status,409,'stale writes blocked');
  result=await call('/api/site','PUT',site,true,{Origin:'https://evil.example'});assert.equal(result.r.status,403);
  const invalid=structuredClone(site);invalid.nodes[0].sources=[{title:'XSS',url:'javascript:alert(1)',note:''}];result=await call('/api/site','PUT',invalid,true);assert.equal(result.r.status,400);
  invalid.nodes[0].sources=[];invalid.nodes[0].links=[{id:'missing',reason:'test'}];result=await call('/api/site','PUT',invalid,true);assert.equal(result.r.status,400);
  const badBlock=structuredClone(site);badBlock.nodes[0].blocks=[{type:'image',url:'/api/state',name:'x'}];result=await call('/api/site','PUT',badBlock,true);assert.equal(result.r.status,400);
  result=await call('/api/feedback','POST',{target:'d-task',type:'解释不清',content:''});assert.equal(result.r.status,400);
  result=await call('/api/feedback','POST',{target:'d-task',type:'解释不清',content:'测试：<img onerror=alert(1)>',nickname:'测试',status:'已处理',reply:'spoof'});assert.equal(result.r.status,201);const id=result.data.record.id;assert.equal(result.data.record.status,'待处理');assert.equal(result.data.record.reply,'');
  result=await call('/api/feedback/'+id,'PATCH',{status:'已处理',reply:'spoof'});assert.equal(result.r.status,401);
  result=await call('/api/feedback/'+id,'PATCH',{status:'处理中',reply:'测试回复',version:'v0.2'},true);assert.equal(result.r.status,200);
  result=await call('/api/feedback');assert.equal(result.data.feedback[0].reply,'测试回复');
  const file=await fetch(base+'/api/upload',{method:'POST',headers:{Cookie:cookie,'X-File-Name':encodeURIComponent('测试.txt')},body:'attachment test'});assert.equal(file.status,200);const asset=await file.json();assert.equal(await(await fetch(base+asset.url)).text(),'attachment test');
  const badImage=await fetch(base+'/api/upload',{method:'POST',headers:{Cookie:cookie,'X-File-Name':'evil.png'},body:'<html>fake image</html>'});assert.equal(badImage.status,400);
  const secret=await fetch(base+'/.runtime/admin.json');assert.equal(secret.status,404);
  result=await call('/api/ai','POST',{question:'概念'});assert.equal(result.r.status,503);
  result=await call('/api/logout','POST',{},true);assert.equal(result.r.status,200);
  result=await call('/api/site','PUT',site,true);assert.equal(result.r.status,401);
});

test('existing admin credentials upgrade at startup and keep working after restart',async()=>{
  const migrationRoot=path.join(dir,'legacy-upgrade'),privateDir=path.join(migrationRoot,'private');
  await fs.mkdir(privateDir,{recursive:true});
  const legacyPassword='test-only-migration-password',salt=randomBytes(24).toString('hex');
  await fs.writeFile(path.join(privateDir,'admin.json'),JSON.stringify({salt,hash:scryptSync(legacyPassword,salt,64).toString('hex')}));
  const probe=net.createServer();probe.listen(0,'127.0.0.1');await once(probe,'listening');
  const port=probe.address().port;await new Promise(resolve=>probe.close(resolve));
  const endpoint='http://127.0.0.1:'+port;
  let child;
  async function start(){
    child=spawn(process.execPath,['server.mjs'],{env:{...process.env,PORT:String(port),HOST:'127.0.0.1',DATA_DIR:path.join(migrationRoot,'data'),RUNTIME_DIR:privateDir,UPLOAD_DIR:path.join(migrationRoot,'uploads'),PUBLIC_ORIGIN:'',ADMIN_PASSWORD:'',AI_API_KEY:'',AI_BASE_URL:'',AI_MODEL:''},stdio:['ignore','pipe','pipe']});
    await new Promise((resolve,reject)=>{child.stdout.once('data',resolve);child.once('error',reject);child.once('exit',code=>reject(new Error('Migration server exited '+code)));});
  }
  async function stop(){if(child){const exit=once(child,'exit');child.kill();await exit;child=null;}}
  const login=pass=>fetch(endpoint+'/api/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:pass})});
  try{
    await start();
    const current=JSON.parse(await fs.readFile(path.join(privateDir,'admin.json'),'utf8'));
    assert.equal(current.iterations,300000);assert.equal(current.version,2);
    assert.equal((await login(legacyPassword)).status,200);
    assert.equal((await login('incorrect')).status,401);
    const publicState=await(await fetch(endpoint+'/api/state')).json();
    assert.equal(publicState.setupRequired,false);assert(!JSON.stringify(publicState).includes(current.hash));
    assert.equal((await fetch(endpoint+'/.runtime/admin.json')).status,404);
    await stop();await start();
    assert.equal((await login(legacyPassword)).status,200);
    assert.deepEqual(JSON.parse(await fs.readFile(path.join(privateDir,'admin.json'),'utf8')),current);
  }finally{await stop();}
});
