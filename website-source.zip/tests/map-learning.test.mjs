import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {findLearningPath,parseTeachingChart,checkTeachingAnswers} from '../public/map-learning.mjs';
const csv=await fs.readFile(new URL('../uploads/4f6cf819-6bfe-4a1b-a56d-5bd8150af002.csv',import.meta.url),'utf8');
test('routes use actual directed links, survive cycles and respect unreachable targets',()=>{
  const nodes=[{id:'a',links:[{id:'b'},{id:'missing'}]},{id:'b',links:[{id:'a'},{id:'c'}]},{id:'c',links:[]},{id:'d',links:[]}];
  assert.deepEqual(findLearningPath(nodes,'a','c').map(n=>n.id),['a','b','c']);
  assert.equal(findLearningPath(nodes,'c','a'),null);assert.equal(findLearningPath(nodes,'a','d'),null);
  assert.equal(findLearningPath(nodes,'absent','c'),null);assert.deepEqual(findLearningPath(nodes,'b','b').map(n=>n.id),['b']);
});
test('practice computes from the attached CSV and rejects unsupported data',()=>{
  const rows=parseTeachingChart('\uFEFF'+csv);
  const answers={highest:'B',difference:'16',ratio:'1.5',performance:'unknown',cause:'unknown'};
  assert(checkTeachingAnswers(rows,answers).every(r=>r.ok));
  assert.deepEqual(checkTeachingAnswers(rows,{...answers,difference:'',ratio:'1.6',performance:'B'}).map(r=>r.ok),[true,false,false,false,true]);
  const changed=parseTeachingChart(csv.replace('A,32','A,24'));
  assert.equal(checkTeachingAnswers(changed,{...answers,difference:24,ratio:2})[2].ok,true,'answers follow changed input rather than hardcoded reference');
  for(const broken of [csv.replace('A,32','A,0'),csv.replace('B,48','A,48'),csv.replace('C,40','C,NaN'),csv.replace('B,48,份','B,48,个'),csv.replace('自制教学数据','真实模型成绩')])assert.throws(()=>parseTeachingChart(broken));
});
