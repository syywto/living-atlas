import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {searchNodes,nodeText} from '../public/content-search.mjs';
const site=JSON.parse(await fs.readFile(new URL('../public/seed.json',import.meta.url),'utf8'));
test('Chinese visitor questions find learning, reasoning and source entries',()=>{
  for(const [question,expected] of [['我想入门，应该从哪里开始学？','d-course'],['模型为什么会瞎编图里的内容？','c-revision'],['有哪些图表问答的论文和数据集？','e-source'],['这张图的数值应该怎么计算？','c-compare']]){
    assert(searchNodes(site.nodes,question).slice(0,3).some(r=>r.n.id===expected),question);
  }
  assert.equal(searchNodes(site.nodes,'明天杭州天气如何？').length,0);
  assert.equal(searchNodes(site.nodes,'  ').length,0);
});
test('retrieval includes tables, charts and edited document content',()=>{
  const n={id:'custom',title:'额外材料',summary:'',blocks:[{type:'table',rows:[['指标','量子纠错']]},{type:'chart',title:'统计图',values:[{label:'测试',value:7}]}],design:{objects:[{type:'text',runs:[{text:'拓扑材料'}]}]}};
  assert.equal(searchNodes([n],'量子纠错')[0].n.id,'custom');
  assert(nodeText(n).includes('拓扑材料'));assert(nodeText(n).includes('测试 7'));
});
