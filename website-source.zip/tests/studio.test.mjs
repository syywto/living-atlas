import {test} from 'node:test';
import assert from 'node:assert/strict';
import {cleanLayout,cleanPageDesigns} from '../lib/studio-schema.mjs';
const rich=[{text:'可保存的样式',font:'SimSun',size:28,bold:true,color:'#0071e3',highlight:'#fff09a',gradient:'ocean'}];
const picture={id:'image-1',type:'image',x:200,y:160,w:400,h:240,rotation:37,url:'/uploads/12345678-abcd.png',name:'test.png',crop:{left:.1,right:.2,top:.1,bottom:0},border:'dashed',feather:18,radius:8};
test('preserves ordered modules, nested sections and rejects duplicate or cyclic placement',()=>{
  const objects=[picture,{id:'group',type:'section',title:'资料板块',runs:rich},{id:'child',type:'section',title:'子板块',runs:[]}];
  const layout=cleanLayout({objects,flow:{root:['base:hero','object:group'],'section:group':['object:image-1','object:child']}});
  assert.equal(layout.mode,'flow');assert.deepEqual(layout.flow.root,['base:hero','object:group']);assert.equal(layout.objects[1].title,'资料板块');assert.deepEqual(layout.flow['section:group'],['object:image-1','object:child']);
  assert.throws(()=>cleanLayout({objects,flow:{root:['object:missing']}}),/不存在/);
  assert.throws(()=>cleanLayout({objects,flow:{root:['object:group'],'section:child':['object:group']}}),/重复/);
  assert.throws(()=>cleanLayout({objects,flow:{'section:group':['object:child'],'section:child':['object:group']}}),/自身/);
});
test('preserves rich text, image transforms, table cell runs and page overrides',()=>{
  const layout=cleanLayout({height:1400,objects:[picture,{id:'table-1',type:'table',x:50,y:450,w:400,h:120,cols:[180,220],rows:[60,60],cells:[[{runs:rich},{runs:[]}],[{runs:[]},{runs:rich}]]},{id:'text-1',type:'text',x:50,y:50,w:400,h:80,runs:rich}]});
  assert.equal(layout.objects[0].rotation,37);assert.equal(layout.objects[0].crop.right,.2);assert.equal(layout.objects[0].feather,18);assert.equal(layout.objects[1].w,400);assert.equal(layout.objects[1].cells[0][0].runs[0].font,'SimSun');assert.equal(layout.objects[2].runs[0].gradient,'ocean');
  const pages=cleanPageDesigns({home:layout},{home:{'section:0/h1:0':{runs:rich,align:'center'}}});assert.equal(pages.pageTexts.home['section:0/h1:0'].align,'center');assert.equal(pages.layouts.home.objects.length,3);
});
test('rejects executable assets, invalid geometry, destructive crop and malformed tables',()=>{
  assert.throws(()=>cleanLayout({objects:[{...picture,url:'javascript:alert(1)'}]}),/地址/);
  assert.throws(()=>cleanLayout({objects:[{...picture,w:Infinity}]}),/数值/);
  assert.throws(()=>cleanLayout({objects:[{...picture,crop:{left:.6,right:.6}}]}),/裁剪/);
  assert.throws(()=>cleanLayout({objects:[picture,picture]}),/重复/);
  assert.throws(()=>cleanLayout({objects:[{id:'t',type:'table',cells:[[{runs:[]}],[{runs:[]},{runs:[]}]]}]}),/列数/);
  const result=cleanLayout({objects:[{id:'t',type:'text',runs:[{text:'x',font:'bad;font',color:'url(evil)',gradient:'url(evil)'}]}]});assert.equal(result.objects[0].runs[0].font,'system');assert.equal(result.objects[0].runs[0].gradient,'none');
});
