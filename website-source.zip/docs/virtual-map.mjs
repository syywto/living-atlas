// Entirely fictional geography, shared by the homepage gateway and the live map.
const lands=[
 {name:'知识之境',x:441,y:266,path:'M179 289C159 255 185 218 222 202C248 191 237 164 264 139C291 114 333 125 361 100C388 77 432 49 469 64C497 75 486 105 521 108C554 109 577 90 605 109C634 129 613 157 640 176C663 191 695 181 708 206C725 240 698 258 674 271C649 286 655 319 626 332C603 344 578 330 553 348C523 370 523 411 486 426C457 437 434 419 409 436C382 456 348 464 319 443C301 429 321 408 301 392C281 377 251 394 231 375C210 357 223 335 205 320C195 311 187 309 179 289Z'},
 {name:'连接群岛',x:1359,y:266,path:'M1177 119C1203 83 1252 65 1302 76C1337 83 1355 105 1384 109C1414 112 1437 97 1469 116C1499 135 1490 160 1515 177C1544 194 1568 204 1574 236C1580 270 1555 282 1558 308C1562 335 1555 361 1530 377C1503 394 1488 381 1462 402C1438 421 1413 445 1383 436C1356 428 1346 402 1318 403C1286 406 1278 432 1248 427C1223 423 1202 405 1200 383C1229 396 1259 387 1274 364C1294 335 1292 309 1318 287C1340 268 1373 274 1394 250C1414 227 1414 196 1392 177C1371 159 1348 171 1325 153C1302 136 1304 114 1276 110C1241 104 1218 126 1193 137C1177 144 1166 137 1177 119Z M1136 219C1155 199 1183 207 1194 229C1207 251 1193 277 1171 278C1148 281 1125 242 1136 219Z M1148 325C1163 310 1185 320 1187 337C1190 356 1172 369 1157 357C1148 350 1140 335 1148 325Z M1255 200C1275 182 1300 191 1301 213C1302 236 1282 251 1265 239C1250 230 1246 211 1255 200Z'},
 {name:'认知高地',x:900,y:602,path:'M623 666C628 631 669 621 689 594C710 567 701 538 734 520C765 503 792 511 814 488C840 459 846 427 880 432C908 436 915 471 939 484C964 498 993 488 1015 506C1039 526 1035 554 1061 570C1091 589 1129 583 1150 610C1172 638 1156 661 1171 685C1188 713 1158 737 1131 741C1103 745 1088 731 1062 748C1037 765 1031 794 999 798C971 800 955 776 929 784C895 795 886 822 850 810C818 799 816 769 789 760C759 751 733 767 707 749C683 732 691 714 669 708C647 703 618 695 623 666Z'}
];
const routes=['M441 266C660 75 1110 52 1359 266','M441 266C420 515 624 704 900 602','M1359 266C1413 550 1150 761 900 602'];
const prefix=s=>String(s).replace(/[^a-zA-Z0-9_-]/g,'');

// Each region has its own drawn landforms rather than scaled copies of a polygon.
const terrain=[
 {contours:[
  'M224 282C211 253 255 242 279 212S313 169 358 160S424 107 467 116S515 154 559 148S614 174 632 206C656 242 609 256 597 286S551 311 523 336S496 391 459 384S407 378 380 408S321 410 326 376S263 347 254 322S234 308 224 282Z',
  'M279 277C282 244 322 237 341 208S386 198 414 167S470 161 494 186S553 171 574 207S544 257 528 286S474 311 453 340S400 330 380 349S346 329 327 314S278 308 279 277Z',
  'M351 270C348 245 389 231 407 213S447 192 469 216S515 231 498 262S461 283 446 305S398 300 385 291S357 291 351 270Z'
 ],river:'M463 116C430 160 472 187 436 223S422 273 390 306S371 350 342 370M391 305C407 323 418 338 416 361M343 369C328 377 317 387 319 408M343 369C352 390 347 406 334 421',
  relief:'M283 232C302 196 342 189 364 171C391 148 416 127 443 130C422 155 418 175 389 188C354 206 328 210 310 237Z M466 302C503 275 528 250 548 224C561 257 548 283 525 305C506 325 487 329 466 334Z'},
 {contours:[
  'M1214 113C1259 84 1285 110 1322 135S1372 140 1398 156C1438 179 1452 214 1426 248S1380 285 1354 309S1332 366 1305 386M1430 138C1458 145 1456 177 1486 196C1517 215 1538 224 1534 250S1513 284 1525 311S1509 352 1483 359S1444 409 1411 401C1388 397 1381 376 1358 378',
  'M1351 141C1383 151 1418 163 1434 189C1450 218 1446 243 1428 264C1405 290 1384 307 1380 338S1403 378 1422 375C1446 370 1453 344 1480 337S1502 313 1493 292S1507 247 1488 228S1449 200 1446 177',
  'M1385 159C1402 168 1418 184 1419 201M1450 247C1468 258 1467 274 1459 291S1443 314 1445 333'
 ],river:'M1478 201C1461 222 1490 242 1472 262S1466 298 1441 316S1429 348 1407 365',
  relief:'M1187 123C1221 88 1269 88 1291 108C1249 94 1224 124 1198 137Z M1497 209C1536 218 1552 239 1540 265C1529 279 1531 291 1533 308C1511 286 1515 270 1520 250C1525 233 1506 222 1497 209Z M1376 389C1404 399 1424 383 1446 366C1444 391 1413 421 1389 416Z'},
 {contours:[
  'M667 673C674 646 713 643 733 612S740 557 777 549S828 528 851 495S878 468 899 500S950 524 977 542S998 581 1037 600S1096 606 1116 636S1104 685 1130 700C1088 696 1070 709 1043 725S1027 765 996 759S956 737 924 748S876 786 850 766S830 729 798 722S743 735 728 706S690 694 667 673Z',
  'M730 669C749 642 774 624 785 592S828 577 849 546S877 521 899 546S944 554 961 583S985 615 1015 626S1072 646 1067 674S1026 685 1007 707S962 695 937 707S892 746 867 722S846 692 814 688S769 709 754 688S736 680 730 669Z',
  'M804 646C829 622 831 592 854 580S888 571 905 596S943 605 950 633S980 666 954 678S919 663 899 685S870 679 850 667S820 667 804 646Z',
  'M851 629C866 615 865 596 879 599S898 620 906 632S895 653 880 649S863 645 851 629Z'
 ],river:'M905 603C924 627 893 644 917 663S938 696 922 724S915 760 890 787M917 663C941 655 966 660 982 675',
  relief:'M697 655C746 633 762 587 782 574C807 557 829 554 854 513C879 473 878 479 898 510C915 538 945 536 968 568C992 603 1024 602 1056 619C1016 620 984 610 956 589C929 569 906 570 886 543C863 570 851 599 819 611C780 626 770 657 734 670Z'}
];
const islets=[
 'M192 393C205 382 223 393 222 405C218 422 198 425 188 412C184 405 185 399 192 393Z M543 433C554 421 575 427 577 441C579 455 562 464 549 455C541 449 536 442 543 433Z',
 'M1534 112C1549 100 1570 110 1568 125C1567 139 1545 143 1535 132C1527 125 1527 118 1534 112Z M1599 323C1618 312 1636 329 1632 345C1629 366 1605 369 1597 350C1593 342 1591 330 1599 323Z M1468 451C1477 440 1496 444 1498 456C1500 472 1484 480 1473 472C1464 467 1462 458 1468 451Z',
 'M649 751C660 740 679 743 681 756C685 771 667 781 656 772C648 768 642 759 649 751Z M1115 785C1133 772 1155 785 1153 801C1152 817 1130 825 1118 813C1107 803 1105 793 1115 785Z'
];

export function virtualMapSVG({id='virtual-map',width=1800,height=860,className='vm-map',x,y}={}){
  id=prefix(id);
  return `<svg class="${className}" ${x===undefined?'':`x="${x}" y="${y}"`} width="${width}" height="${height}" viewBox="0 0 1800 860" preserveAspectRatio="none" aria-hidden="true">
  <defs>
    <pattern id="${id}-grid" width="45" height="45" patternUnits="userSpaceOnUse"><path d="M45 0H0V45" class="vm-grid-line" fill="none"/><circle cx="1" cy="1" r="1" class="vm-grid-dot"/></pattern>
    <linearGradient id="${id}-scan"><stop stop-color="#74dbe9" stop-opacity="0"/><stop offset=".75" stop-color="#74dbe9" stop-opacity=".13"/><stop offset="1" stop-color="#74dbe9" stop-opacity="0"/></linearGradient>
    ${lands.map((l,i)=>`<linearGradient id="${id}-tone-${i}" x1="0" y1="0" x2=".7" y2="1"><stop class="vm-tone-${i}-light"/><stop offset="1" class="vm-tone-${i}-shade"/></linearGradient><path id="${id}-land-${i}" d="${l.path}"/>`).join('')}
    <clipPath id="${id}-clip">${lands.map((l,i)=>`<use href="#${id}-land-${i}"/>`).join('')}</clipPath>
  </defs>
  <rect width="1800" height="860" class="vm-ocean"/><rect width="1800" height="860" fill="url(#${id}-grid)"/>
  <g class="vm-sea-rings" fill="none">${lands.map((l,i)=>`<use href="#${id}-land-${i}" class="vm-coast-${i}" stroke-width="42"/><use href="#${id}-land-${i}" class="vm-coast-${i}" stroke-width="19"/>`).join('')}</g>
  <g class="vm-islands">${lands.map((l,i)=>`<g class="vm-biome-${i}"><use href="#${id}-land-${i}" fill="url(#${id}-tone-${i})" class="vm-land vm-land-${i}"/><use href="#${id}-land-${i}" class="vm-beach" fill="none"/><path d="${islets[i]}" fill="url(#${id}-tone-${i})" class="vm-islet vm-coast-${i}"/></g>`).join('')}</g>
  <g clip-path="url(#${id}-clip)">
    ${terrain.map((t,i)=>`<g class="vm-biome-${i}"><path d="${t.relief}" class="vm-relief"/><g class="vm-contour-lines" fill="none">${t.contours.map(d=>`<path d="${d}"/>`).join('')}</g><path d="${t.river}" class="vm-rivers" fill="none"/></g>`).join('')}
    <path class="vm-lake" d="M491 211C510 202 531 209 530 222C528 238 512 248 499 239C490 231 481 221 491 211Z M835 710C845 702 859 711 855 721C851 731 833 733 830 723C828 717 829 715 835 710Z"/>
    <g class="vm-ridge" fill="none"><path d="M716 651C750 625 767 597 793 583S842 559 864 512C879 538 893 550 918 557S952 568 971 591S1015 610 1038 618M864 512C866 548 859 571 868 598M793 583C816 591 826 607 830 628M918 557C915 581 929 593 939 603"/></g>
    <g class="vm-woodland">${[[304,218],[321,201],[337,193],[350,184],[367,177],[375,192],[352,205],[329,221],[315,234],[491,321],[507,303],[523,289],[1290,120],[1305,132],[1320,141],[1508,235],[1514,251]].map(([cx,cy],i)=>`<ellipse cx="${cx}" cy="${cy}" rx="${i%3+3}" ry="${i%3+5}" transform="rotate(-28 ${cx} ${cy})"/>`).join('')}</g>
    <g class="vm-scan"><rect x="-220" y="0" width="220" height="860" fill="url(#${id}-scan)"/><path d="M-4 0V860"/></g>
  </g>
  <g class="vm-navigation" fill="none">${routes.map(d=>`<path class="vm-route" d="${d}"/>`).join('')}</g>
  <g class="vm-packets">${routes.map((d,i)=>`<circle r="3" class="vm-packet"><animateMotion dur="${8+i*2}s" repeatCount="indefinite" path="${d}"/></circle>`).join('')}</g>
  <g class="vm-beacons">${lands.map((l,i)=>`<g transform="translate(${l.x} ${l.y})"><circle class="vm-beacon-ring" r="35" style="animation-delay:${-i*1.3}s"/><circle r="8"/><path d="M-18 0H18M0-18V18"/></g>`).join('')}</g>
  <g class="vm-zone-labels"><text x="270" y="414">01 / 知识之境</text><text x="1425" y="423">02 / 连接群岛</text><text x="1009" y="772">03 / 认知高地</text><text x="855" y="158" class="vm-sea-label">THE OPEN CURRENT</text><text x="175" y="650" class="vm-sea-label">UNKNOWN / 待探索海域</text></g>
  <g class="vm-coordinate-marks" fill="none"><path d="M50 75V50H75m1650 0h25v25M50 785v25h25m1550 0h25v-25"/><path d="M865 38h70m-35-12v24M45 395v70m-12-35h24M1725 395v70m-12-35h24"/></g></svg>`;
}
export function mapPortalHTML(count){
  const fold='M100 85 350 38 625 82 900 32V343L625 395 350 351 100 405Z';
  return `<button type="button" class="atlas-portal" data-action="atlas" aria-label="展开三张活地图，${count}个内容条目"><span class="atlas-portal-orbit" aria-hidden="true"></span><svg class="atlas-portal-art" viewBox="0 0 1000 440" fill="none" aria-hidden="true"><defs><clipPath id="portal-fold"><path d="${fold}"/></clipPath><linearGradient id="portal-shine" x1="0" y1="0" x2="1" y2="0"><stop stop-color="#fff" stop-opacity=".3"/><stop offset=".35" stop-color="#fff" stop-opacity="0"/><stop offset=".63" stop-color="#407f9a" stop-opacity=".07"/><stop offset="1" stop-color="#fff" stop-opacity=".1"/></linearGradient></defs><path class="atlas-paper-shadow" d="${fold}" transform="translate(0 16)"/><g clip-path="url(#portal-fold)">${virtualMapSVG({id:'portal-world',width:900,height:430,x:50,y:0})}<path d="${fold}" fill="url(#portal-shine)"/><path d="M350 38V351M625 82V395" class="atlas-fold-line"/><path d="M350 39V351M625 83V395" transform="translate(2 0)" class="atlas-fold-highlight"/></g><path class="atlas-paper-edge" d="${fold}"/><g class="atlas-portal-pins"><g transform="translate(268 145)"><circle class="atlas-pin-halo" r="24"/><circle r="8"/><path d="M-13 0h26M0-13v26"/><text y="-36">领域地图</text></g><g transform="translate(733 145)"><circle class="atlas-pin-halo" r="24"/><circle r="8"/><path d="M-13 0h26M0-13v26"/><text y="-36">生态地图</text></g><g transform="translate(500 292)"><circle class="atlas-pin-halo" r="24"/><circle r="8"/><path d="M-13 0h26M0-13v26"/><text y="44">认知地图</text></g></g></svg><span class="atlas-portal-caption"><span class="atlas-portal-indicator" aria-hidden="true"></span><span><strong>展开三张活地图</strong><small>${count} 个条目，沿着关联探索</small></span><span class="atlas-portal-enter" aria-hidden="true">↗</span></span><span class="atlas-portal-coordinate" aria-hidden="true">EXPLORE / CONNECT / DISCOVER</span></button>`;
}

export function expandMapPortal(dialog,source){
  if(!source||window.matchMedia('(prefers-reduced-motion: reduce)').matches)return ()=>{};
  const sourceArt=source.querySelector('.atlas-portal-art');if(!sourceArt)return ()=>{};
  const rect=sourceArt.getBoundingClientRect(),art=sourceArt.cloneNode(true),overlay=document.createElement('div');
  overlay.className='atlas-unfold-overlay';overlay.setAttribute('aria-hidden','true');
  const ids=new Map([...art.querySelectorAll('[id]')].map(el=>[el.id,el.id+'-flight']));
  for(const el of art.querySelectorAll('*')){
    if(el.id)el.id=ids.get(el.id);
    for(const attr of ['href','xlink:href','clip-path','fill','stroke','filter','mask']){let value=el.getAttribute(attr);if(!value)continue;for(const [old,id]of ids)value=value.replaceAll(`url(#${old})`,`url(#${id})`).replace(value==='#'+old?value:'\0','#'+id);el.setAttribute(attr,value);}
  }
  overlay.append(art);dialog.append(overlay);dialog.classList.add('has-portal-transition');
  const dx=rect.left+rect.width/2-innerWidth/2,dy=rect.top+rect.height/2-innerHeight/2;
  const ratio=1000/440,artWidth=Math.max(innerWidth,innerHeight*ratio)*1.12,sourceWidth=Math.min(rect.width,rect.height*ratio);
  Object.assign(art.style,{inset:'auto',left:'50%',top:'50%',width:artWidth+'px',height:artWidth/ratio+'px'});
  const base='translate(-50%,-50%)',start=`${base} translate(${dx}px,${dy}px) scale(${sourceWidth/artWidth}) rotateX(12deg)`;
  const animations=[
    art.animate([{transform:start,opacity:1},{transform:base+' scale(.96) rotateX(0)',opacity:1,offset:.66},{transform:base+' scale(1.2) rotateX(0)',opacity:0}],{duration:850,easing:'cubic-bezier(.2,.75,.2,1)',fill:'both'}),
    dialog.querySelector('.fa-shell').animate([{opacity:0,transform:'scale(.97)'},{opacity:1,transform:'scale(1)'}],{duration:650,delay:110,easing:'cubic-bezier(.2,.7,.2,1)',fill:'both'})
  ];
  dialog.querySelectorAll('.fa-marker-position').forEach((el,i)=>animations.push(el.animate([{opacity:0,transform:'translate(-50%,-40%) scale(.86)'},{opacity:1,transform:'translate(-50%,-50%) scale(1)'}],{duration:440,delay:220+i%6*35,easing:'cubic-bezier(.2,.7,.2,1)',fill:'both'})));
  let disposed=false;
  const cleanup=()=>{if(disposed)return;disposed=true;animations.forEach(a=>a.cancel());overlay.remove();};
  Promise.allSettled(animations.map(a=>a.finished)).then(cleanup);return cleanup;
}
