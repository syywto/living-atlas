// Only existing, directed relationships may appear in a learning route.
export function findLearningPath(nodes,from,to){
  const byId=new Map(nodes.map(n=>[n.id,n]));
  if(!byId.has(from)||!byId.has(to))return null;
  const queue=[[from]],seen=new Set([from]);
  for(let i=0;i<queue.length;i++){
    const path=queue[i],id=path.at(-1);if(id===to)return path.map(id=>byId.get(id));
    for(const link of byId.get(id).links||[])if(byId.has(link.id)&&!seen.has(link.id)){
      seen.add(link.id);queue.push([...path,link.id]);
    }
  }
  return null;
}

export function parseTeachingChart(csv){
  const lines=String(csv).replace(/^\uFEFF/,'').trim().split(/\r?\n/);
  if(lines.length!==4||lines[0]!=='组别,样本量,单位,数据性质')throw new Error('练习 CSV 的表头或行数已变化，请先核对练习材料。');
  const rows=lines.slice(1).map(line=>{
    const cells=line.split(',');
    if(cells.length!==4||!['A','B','C'].includes(cells[0])||!/^\d+(\.\d+)?$/.test(cells[1])||!cells[2]||cells[3]!=='自制教学数据')throw new Error('练习只接受 A、B、C 三组非负数的自制教学数据。');
    return {label:cells[0],value:Number(cells[1]),unit:cells[2]};
  });
  if(new Set(rows.map(r=>r.label)).size!==3||new Set(rows.map(r=>r.unit)).size!==1||rows.some(r=>!Number.isFinite(r.value)||r.value>1e9)||rows.find(r=>r.label==='A').value===0)throw new Error('数据重复、单位不一致或 A 为零，无法按当前五题核查。');
  return rows;
}

export function checkTeachingAnswers(rows,answers){
  const values=Object.fromEntries(rows.map(r=>[r.label,r.value]));
  const unit=rows[0].unit,max=Math.max(...Object.values(values));
  const highest=rows.filter(r=>r.value===max).map(r=>r.label);
  const near=(actual,expected)=>String(actual).trim()!==''&&Number.isFinite(Number(actual))&&Math.abs(Number(actual)-expected)<=Math.max(1e-8,Math.abs(expected)*1e-6);
  return [
    {ok:highest.length===1&&answers.highest===highest[0],label:'标签与读数',explanation:highest.length===1?`${highest[0]} 组最多，为 ${max} ${unit}。请同时核对组别与数值。`:`${highest.join('、')} 并列最多；原题需改为允许多选。`},
    {ok:near(answers.difference,values.B-values.A),label:'差值计算',explanation:`B − A = ${values.B} − ${values.A} = ${values.B-values.A} ${unit}。`},
    {ok:near(answers.ratio,values.B/values.A),label:'倍数与基准',explanation:`B ÷ A = ${values.B} ÷ ${values.A} = ${Number((values.B/values.A).toPrecision(8))} 倍；分母是比较基准 A。`},
    {ok:answers.performance==='unknown',label:'指标边界',explanation:'无法判断。图表给出样本量，没有模型准确率或其他性能指标。'},
    {ok:answers.cause==='unknown',label:'因果边界',explanation:'无法从图中确定原因。需要实验设计或其他材料，不能从样本数补出因果解释。'}
  ];
}
