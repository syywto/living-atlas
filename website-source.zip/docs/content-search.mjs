const stop=new Set(['怎么','怎样','如何','什么','为什么','哪些','哪个','可以','能够','是否','一个','这个','我们','你们','我的','你','的','了','是','在','我','请','想','问','有','吗','呢','与','和','及','用','应该','需要']);
const segmenter=typeof Intl.Segmenter==='function'?new Intl.Segmenter('zh-CN',{granularity:'word'}):null;
export function questionTerms(question){
  const raw=String(question||'').toLowerCase().trim();
  const segments=segmenter?[...segmenter.segment(raw)].filter(s=>s.isWordLike).map(s=>s.segment):(raw.match(/[a-z0-9_-]+|[\u3400-\u9fff]{2,}/g)||[]);
  return [...new Set(segments.filter(s=>s.length>1&&!stop.has(s)))];
}
export function nodeText(node){
  const parts=[node.title,node.summary,node.category,node.question];
  for(const b of node.blocks||[]){
    if(b.runs)parts.push(b.runs.map(r=>r.text).join(''));
    if(b.rows)parts.push(b.rows.flat().join(' '));
    if(b.type==='chart')parts.push(b.title,...b.values.map(v=>v.label+' '+v.value));
    if(['image','file'].includes(b.type))parts.push(b.caption,b.name);
  }
  for(const o of node.design?.objects||[]){
    if(o.runs)parts.push(o.runs.map(r=>r.text).join(''));
    if(o.cells)parts.push(...o.cells.flat().map(c=>c.runs.map(r=>r.text).join('')));
    if(o.type==='chart')parts.push(o.title,...o.values.map(v=>v.label+' '+v.value));
    if(o.caption)parts.push(o.caption);
  }
  return parts.filter(Boolean).join('\n');
}
const intents=[
  [['从哪学','哪里学','入门','课程','学习路线','学习路径','基础'],['d-course','c-plan']],
  [['看不懂','术语','编码','对齐','概念'],['d-concept','d-tool']],
  [['图表','读数','算错','计算','ocr','比较两种'],['c-compare','d-task','d-tool']],
  [['幻觉','编造','瞎编','可靠','证据','可信','不确定'],['c-revision','d-concept','e-source']],
  [['论文','资料','文献','出处','数据集','评测','chartqa','pope','mmmu'],['e-source','e-frontier']],
  [['研究什么','这个网站','本站','选题','三张地图'],['d-task','d-concept']],
  [['参与者','作者','团队','谁提出'],['e-actor','e-chain']],
  [['成本','费用','许可','部署','资源依赖'],['e-chain','d-tool']],
  [['习惯','每周','维护'],['c-habit','c-plan']]
];
export function searchNodes(nodes,question,limit=6){
  const raw=String(question||'').toLowerCase().trim();if(!raw)return [];
  const words=questionTerms(raw);
  return nodes.map(n=>{
    const title=n.title.toLowerCase(),summary=n.summary.toLowerCase(),body=nodeText(n).toLowerCase();
    let score=words.reduce((s,w)=>s+(title.includes(w)?7:summary.includes(w)?4:body.includes(w)?1:0),0);
    if(raw.length>1&&title.includes(raw))score+=15;
    if(raw.length>1&&body.includes(raw))score+=4;
    for(const [triggers,targets] of intents)if(triggers.some(t=>raw.includes(t))&&targets.includes(n.id))score+=12-targets.indexOf(n.id)*2;
    return {n,score};
  }).filter(r=>r.score>0).sort((a,b)=>b.score-a.score||a.n.id.localeCompare(b.n.id)).slice(0,limit);
}
