/* Local, structured page/document authoring. No external libraries or services. */
(() => {
'use strict';
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const copy=v=>structuredClone(v),clamp=(v,a,b)=>Math.min(b,Math.max(a,v)),uid=()=> 's-'+crypto.randomUUID().slice(0,14);
const fonts={system:'系统字体','Microsoft YaHei':'微软雅黑',SimSun:'宋体',SimHei:'黑体',KaiTi:'楷体',Arial:'Arial','Times New Roman':'Times New Roman',Georgia:'Georgia'};
const gradients={none:'',ocean:'linear-gradient(90deg,#0071e3,#a350dc)',sunset:'linear-gradient(90deg,#e45b50,#c58b00)',forest:'linear-gradient(90deg,#08785d,#1886a2)',violet:'linear-gradient(90deg,#7c3ab9,#d3489f)'};
const gradientNames={none:'无渐变',ocean:'蓝紫渐变',sunset:'日落渐变',forest:'青绿渐变',violet:'紫红渐变'};
const views={home:'首页',domain:'领域地图',ecology:'生态地图',cognition:'认知地图',journal:'更新记录',feedback:'反馈',about:'关于'};
const plain=(text='',size=16)=>[{text,color:'#1d1d1f',font:'system',size}];
let config,pageSession=null,pageSurface=null,active=null,docSession=null,view='home',selection=null,textTarget=null,selectionLocked=false,editingPaused=false,baseOriginals=new WeakMap();
function status(message){const el=$('#toast');el.textContent=message;el.classList.add('show');clearTimeout(status.timer);status.timer=setTimeout(()=>el.classList.remove('show'),3500);}
function asset(url){return /^\/uploads\/[a-f0-9-]+\.[a-z0-9]+$/.test(url)?(config?.isStatic()?'.'+url:url):'';}
function runsHTML(runs){return (runs||[]).map(r=>{
  const size=clamp(Number(r.size)||16,8,120),font=Object.hasOwn(fonts,r.font)?r.font:'system';
  const styles=[`font-size:${size}px`,`font-family:${font==='system'?'inherit':"'"+font+"'"}`];
  if(r.bold)styles.push('font-weight:700');if(r.italic)styles.push('font-style:italic');if(r.underline)styles.push('text-decoration:underline');
  if(/^#[a-f0-9]{6}$/i.test(r.color)&&r.color.toLowerCase()!=='#1d1d1f')styles.push('color:'+r.color);
  if(/^#[a-f0-9]{6}$/i.test(r.highlight))styles.push('background-color:'+r.highlight);
  if(gradients[r.gradient])styles.push('--st-gradient:'+gradients[r.gradient]);
  return `<span class="${r.color?.toLowerCase()==='#1d1d1f'||!r.color?'st-default ':''}${gradients[r.gradient]?'st-gradient':''}" data-gradient="${Object.hasOwn(gradients,r.gradient)?r.gradient:'none'}" style="${esc(styles.join(';'))}">${esc(r.text)}</span>`;
}).join('');}
function hex(value){if(/^#[a-f0-9]{6}$/i.test(value))return value;const rgb=value?.match(/\d+/g);return rgb?.length>=3?'#'+rgb.slice(0,3).map(v=>clamp(Number(v),0,255).toString(16).padStart(2,'0')).join(''):'';}
function readRuns(root){
  const result=[],initial={color:'#1d1d1f',font:'system',size:clamp(parseFloat(getComputedStyle(root).fontSize)||16,8,120),bold:false,italic:false,underline:false,highlight:'',gradient:'none'};
  function add(text,style){text=text.replace(/\u200b/g,'');if(!text)return;const last=result.at(-1);if(last&&Object.keys(style).every(k=>style[k]===last[k]))last.text+=text;else result.push({text,...style});}
  function walk(n,style){
    if(n.nodeType===3){add(n.textContent,style);return;}if(n.nodeType!==1||['BUTTON','SCRIPT','STYLE','IFRAME','OBJECT'].includes(n.tagName))return;
    if(n.tagName==='BR'){add('\n',style);return;}const s={...style};
    if(n!==root){
      if(['B','STRONG'].includes(n.tagName))s.bold=true;if(['I','EM'].includes(n.tagName))s.italic=true;if(n.tagName==='U')s.underline=true;
      if(n.style.fontWeight)s.bold=Number(n.style.fontWeight)>=600||n.style.fontWeight==='bold';if(n.style.fontStyle)s.italic=n.style.fontStyle==='italic';if(n.style.textDecoration)s.underline=n.style.textDecoration.includes('underline');
      const color=hex(n.style.color||n.getAttribute('color'));if(color)s.color=color;
      const font=(n.style.fontFamily||n.getAttribute('face')||'').replace(/["']/g,'').split(',')[0].trim();if(Object.hasOwn(fonts,font))s.font=font;
      if(n.style.fontSize)s.size=clamp(parseFloat(n.style.fontSize)||16,8,120);
      if(n.style.backgroundColor)s.highlight=hex(n.style.backgroundColor);
      if(Object.hasOwn(gradients,n.dataset.gradient))s.gradient=n.dataset.gradient;
      if(['DIV','P'].includes(n.tagName)&&result.length&&!result.at(-1).text.endsWith('\n'))add('\n',style);
    }
    n.childNodes.forEach(child=>walk(child,s));
  }
  root.childNodes.forEach(n=>walk(n,initial));return result.length?result:plain('',initial.size);
}
function chartHTML(o){
  const values=o.values||[],max=Math.max(...values.map(v=>v.value),1);
  if(o.chartType==='column')return `<div class="st-chart"><h4>${esc(o.title)}</h4><div class="st-columns">${values.map(v=>`<div class="st-column"><span>${v.value}</span><i style="height:${v.value/max*80}%;background:${o.color||'#508de0'}"></i><small>${esc(v.label)}</small></div>`).join('')}</div></div>`;
  return `<div class="st-chart"><h4>${esc(o.title)}</h4>${values.map(v=>`<div class="st-bar"><span>${esc(v.label)}</span><i><b style="width:${v.value/max*100}%;background:${o.color||'#508de0'}"></b></i><small>${v.value}</small></div>`).join('')}</div>`;
}
function bodyHTML(o,editable=false){
  if(o.type==='section')return `<section class="fm-section"><h2 class="fm-section-title" ${editable?'contenteditable="true" aria-label="板块标题"':''}>${esc(o.title||'新板块')}</h2><div class="st-text" ${editable?'contenteditable="true" role="textbox" aria-label="板块正文"':''}>${runsHTML(o.runs)}</div><div class="fm-section-children" data-section-children="${o.id}"></div></section>`;
  if(o.type==='text')return `<div class="st-text" ${editable?'contenteditable="true" role="textbox" aria-label="编辑文字" aria-multiline="true"':''} style="text-align:${o.align||'left'}">${runsHTML(o.runs)}</div>`;
  if(o.type==='image'){
    const c=o.crop||{left:0,top:0,right:0,bottom:0},x=1-c.left-c.right,y=1-c.top-c.bottom;
    const feather=o.feather?`mask-image:linear-gradient(to right,transparent,black ${o.feather}px,black calc(100% - ${o.feather}px),transparent),linear-gradient(to bottom,transparent,black ${o.feather}px,black calc(100% - ${o.feather}px),transparent);mask-composite:intersect;`:'';
    return `<div class="st-image-frame" style="border-radius:${o.radius||0}px;${o.border==='solid'||o.border==='dashed'?`border:${o.borderWidth||1}px ${o.border} ${o.borderColor||'#b9c7db'};`:''}${o.border==='soft'?'box-shadow:0 0 18px 5px #52668040;':''}${feather}"><img src="${esc(asset(o.url))}" alt="${esc(o.caption||o.name)}" draggable="false" style="width:${100/x}%;height:${100/y}%;left:${-c.left/x*100}%;top:${-c.top/y*100}%"></div>`;
  }
  if(o.type==='table')return `<table class="st-table" style="--st-table-border:${o.borderColor||'#b8c3d5'}"><colgroup>${o.cols.map(w=>`<col style="width:${w}px">`).join('')}</colgroup><tbody>${o.cells.map((row,r)=>`<tr style="height:${o.rows[r]}px">${row.map((cell,c)=>`<td class="${o.header&&r===0?'st-table-header':''}" style="text-align:${cell.align||'left'}"><div class="st-cell" ${editable?`contenteditable="true" role="textbox" aria-label="第 ${r+1} 行第 ${c+1} 列" data-cell="${r},${c}"`:''}>${runsHTML(cell.runs)}</div>${editable?`<span class="st-cell-grip" data-cell-resize="${r},${c}" title="拖动调整此列宽度和此行高度"></span>`:''}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
  if(o.type==='chart')return chartHTML(o);
  return `<a class="attachment st-file" href="${esc(asset(o.url))}" download="${esc(o.name)}"><span class="file-icon">▤</span><span>${esc(o.name)}<small>${esc(o.caption||'点击下载附件')}</small></span><span class="download">↓</span></a>`;
}
function controlsHTML(o){return `<button class="st-move" type="button" data-drag="move" aria-label="移动${o.type==='image'?'图片':o.type==='table'?'表格':'对象'}">⠿ 拖动</button><button class="st-remove" type="button" data-object-command="remove" aria-label="删除选中对象">×</button>${['nw','n','ne','e','se','s','sw','w'].map(p=>`<span class="st-handle st-handle-${p}" data-drag="${p}" role="button" aria-label="${p==='se'?'右下角':p}缩放控点" tabindex="0"></span>`).join('')}<span class="st-rotate-line"></span><button class="st-rotate" type="button" data-drag="rotate" aria-label="旋转对象" title="拖动绕中心旋转；Shift 按 15° 对齐"></button>${o.type==='table'?'<button class="st-add-col" type="button" data-object-command="column" aria-label="在右侧添加一列">＋</button><button class="st-add-row" type="button" data-object-command="row" aria-label="在下方添加一行">＋</button>':''}`;}
function objectHTML(o,editable=false){return `<div class="st-object st-kind-${o.type}" data-object-id="${o.id}" style="left:${o.x}px;top:${o.y}px;width:${o.w}px;height:${o.h}px;transform:rotate(${o.rotation||0}deg)"><div class="st-object-body">${bodyHTML(o,editable)}</div>${editable?controlsHTML(o):''}</div>`;}
const viewLayouts=new Map(),viewSurfaces=new Set();
function designHTML(layout){const key=uid();viewLayouts.set(key,copy(layout));return `<div class="fm-document-view" data-layout-view="${key}"></div>`;}
function fitViews(root=document){for(const surface of viewSurfaces)if(!surface.host.isConnected){surface.destroy();viewSurfaces.delete(surface);}$$('[data-layout-view]',root).forEach(el=>{const layout=viewLayouts.get(el.dataset.layoutView);if(layout){viewSurfaces.add(new FlowSurface(el,layout,false,()=>{},'viewer'));viewLayouts.delete(el.dataset.layoutView);}});}
class Surface{
  constructor(host,layout,editable,onChange,kind='page'){
    this.host=host;this.layout=layout;this.editable=editable;this.onChange=onChange;this.kind=kind;this.selected=null;this.crop=null;
    this.layer=document.createElement('div');this.layer.className='st-layer';this.layer.innerHTML='<div class="st-guide st-guide-x" hidden></div><div class="st-guide st-guide-y" hidden></div>';
    host.append(this.layer);host.classList.add('st-surface');this.baseHeight=host.scrollHeight;this.scale=host.clientWidth/1000;
    this.observer=new ResizeObserver(()=>this.geometry());this.observer.observe(host);this.paint();
    this.layer.addEventListener('pointerdown',e=>this.pointerDown(e));
    this.layer.addEventListener('click',e=>{const command=e.target.closest('[data-object-command]');if(command){e.preventDefault();this.command(command.dataset.objectCommand);}else{const object=e.target.closest('.st-object');if(object)this.select(object.dataset.objectId);}});
    this.layer.addEventListener('input',e=>{this.capture(e.target);this.changed();});
    this.layer.addEventListener('focusin',e=>{const node=e.target.closest('.st-object');if(node)this.select(node.dataset.objectId);});
    this.layer.addEventListener('paste',plainPaste);
  }
  destroy(){this.observer.disconnect();this.layer.remove();this.host.classList.remove('st-surface');this.host.style.minHeight='';}
  geometry(){
    this.scale=this.host.clientWidth/1000;if(!this.scale)return;
    const max=Math.max(this.layout.height||600,...this.layout.objects.map(o=>o.y+o.h+60));
    const height=this.kind==='page'?Math.max(this.baseHeight,max*this.scale):max*this.scale;
    if(Math.abs((parseFloat(this.host.style.minHeight)||0)-height)>1)this.host.style.minHeight=height+'px';
    this.layer.style.height=Math.max(max,height/this.scale)+'px';this.layer.style.transform=`scale(${this.scale})`;
  }
  paint(){
    $$('.st-object',this.layer).forEach(el=>el.remove());
    this.layer.insertAdjacentHTML('beforeend',this.layout.objects.map(o=>objectHTML(o,this.editable)).join(''));
    this.layer.classList.toggle('st-is-editable',this.editable);this.geometry();this.select(this.selected,false);
  }
  select(id,notify=true){this.selected=id;$$('.st-object',this.layer).forEach(el=>el.classList.toggle('st-selected',el.dataset.objectId===id));if(notify&&this.editable){active=this;renderInspector();}}
  get item(){return this.layout.objects.find(o=>o.id===this.selected);}
  capture(el){const node=el.closest('.st-object');if(!node)return;const item=this.layout.objects.find(o=>o.id===node.dataset.objectId);if(item.type==='text')item.runs=readRuns($('.st-text',node));if(item.type==='table')$$('[data-cell]',node).forEach(cell=>{const [r,c]=cell.dataset.cell.split(',').map(Number);item.cells[r][c].runs=readRuns(cell);});}
  captureAll(){$$('.st-text,.st-cell',this.layer).forEach(el=>this.capture(el));}
  changed(){this.onChange();this.geometry();updateStatus();}
  update(){const node=$(`[data-object-id="${this.selected}"]`,this.layer),o=this.item;if(node&&o){node.style.cssText=`left:${o.x}px;top:${o.y}px;width:${o.w}px;height:${o.h}px;transform:rotate(${o.rotation||0}deg)`;}this.geometry();}
  refreshBody(){const el=$(`[data-object-id="${this.selected}"] .st-object-body`,this.layer);if(el)el.innerHTML=bodyHTML(this.item,this.editable);}
  add(o){this.captureAll();o.id=uid();this.layout.objects.push(o);this.paint();this.select(o.id);this.changed();if(o.type==='text')$(`[data-object-id="${o.id}"] .st-text`,this.layer)?.focus();}
  command(command){
    const o=this.item;if(!o)return;this.captureAll();checkpoint();
    if(command==='remove'){this.layout.objects=this.layout.objects.filter(v=>v.id!==o.id);this.selected=null;this.crop=null;}
    if(command==='row'&&o.type==='table'){if(o.cells.length>=40)return status('表格最多 40 行。');o.cells.push(o.cols.map(()=>({runs:plain(''),align:'left'})));o.rows.push(44);o.h=o.rows.reduce((a,b)=>a+b,0);}
    if(command==='column'&&o.type==='table'){if(o.cols.length>=12)return status('表格最多 12 列。');const width=Math.min(100,(1000-o.x)/(o.cols.length+1));o.cols=o.cols.map(()=>width);o.cols.push(width);o.cells.forEach(row=>row.push({runs:plain(''),align:'left'}));o.w=o.cols.reduce((a,b)=>a+b,0);}
    if(command==='front'){this.layout.objects=this.layout.objects.filter(v=>v!==o);this.layout.objects.push(o);}
    if(command==='back'){this.layout.objects=this.layout.objects.filter(v=>v!==o);this.layout.objects.unshift(o);}
    if(command==='copy'){const next=copy(o);next.x=clamp(next.x+20,0,1000-next.w);next.y+=20;return this.add(next);}
    this.paint();renderInspector();this.changed();
  }
  guides(o){
    const bounds=v=>{const a=(v.rotation||0)*Math.PI/180,w=Math.abs(v.w*Math.cos(a))+Math.abs(v.h*Math.sin(a)),h=Math.abs(v.w*Math.sin(a))+Math.abs(v.h*Math.cos(a));return {x:v.x+(v.w-w)/2,y:v.y+(v.h-h)/2,w,h};};
    const others=this.layout.objects.filter(v=>v.id!==o.id).map(bounds),box=bounds(o),xRefs=[24,500,976,...others.flatMap(v=>[v.x,v.x+v.w/2,v.x+v.w])],yRefs=[...others.flatMap(v=>[v.y,v.y+v.h/2,v.y+v.h])];
    const snap=(pos,size,refs)=>{let best;for(const offset of [0,size/2,size])for(const ref of refs){const d=ref-(pos+offset);if(Math.abs(d)<7/this.scale&&(!best||Math.abs(d)<Math.abs(best.d)))best={d,ref};}return best;};
    const sx=snap(box.x,box.w,xRefs),sy=snap(box.y,box.h,yRefs),gx=$('.st-guide-x',this.layer),gy=$('.st-guide-y',this.layer);gx.hidden=!sx;gy.hidden=!sy;
    if(sx){o.x=clamp(o.x+sx.d,0,1000-o.w);gx.style.left=sx.ref+'px';}if(sy){o.y=Math.max(0,o.y+sy.d);gy.style.top=sy.ref+'px';}
  }
  pointerDown(e){
    if(!this.editable||e.button!==0)return;const node=e.target.closest('.st-object');if(!node)return;
    this.select(node.dataset.objectId);const o=this.item,grip=e.target.closest('[data-cell-resize]'),handle=e.target.closest('[data-drag]');
    if(e.target.closest('[data-object-command]'))return;
    if(!handle&&!grip&&(e.target.closest('[contenteditable]')||['text','table','file'].includes(o.type)))return;
    e.preventDefault();this.captureAll();checkpoint();const original=copy(o),start={x:e.clientX,y:e.clientY},mode=grip?'cell':handle?.dataset.drag||'move';
    const center={x:node.getBoundingClientRect().left+node.getBoundingClientRect().width/2,y:node.getBoundingClientRect().top+node.getBoundingClientRect().height/2};
    const startAngle=Math.atan2(e.clientY-center.y,e.clientX-center.x)*180/Math.PI;
    const move=event=>{
      const dx=(event.clientX-start.x)/this.scale,dy=(event.clientY-start.y)/this.scale;
      if(mode==='move'){o.x=clamp(original.x+dx,0,1000-o.w);o.y=clamp(original.y+dy,0,29000);this.guides(o);}
      else if(mode==='rotate'){o.rotation=original.rotation+Math.atan2(event.clientY-center.y,event.clientX-center.x)*180/Math.PI-startAngle;if(event.shiftKey)o.rotation=Math.round(o.rotation/15)*15;}
      else if(mode==='cell'){
        const [r,c]=grip.dataset.cellResize.split(',').map(Number);o.cols[c]=clamp(original.cols[c]+dx,32,Math.max(32,1000-o.x-original.w+original.cols[c]));o.rows[r]=clamp(original.rows[r]+dy,28,1000);o.w=o.cols.reduce((a,b)=>a+b,0);o.h=o.rows.reduce((a,b)=>a+b,0);this.refreshBody();
      }else{
        const angle=original.rotation*Math.PI/180,rx=dx*Math.cos(angle)+dy*Math.sin(angle),ry=-dx*Math.sin(angle)+dy*Math.cos(angle);
        let w=original.w+(mode.includes('e')?rx:mode.includes('w')?-rx:0),h=original.h+(mode.includes('s')?ry:mode.includes('n')?-ry:0);
        if(o.type==='image'&&mode.length===2&&!event.shiftKey){const ratio=original.w/original.h;if(Math.abs(rx)>Math.abs(ry))h=w/ratio;else w=h*ratio;}
        o.w=clamp(w,o.type==='table'?o.cols.length*32:60,1000);o.h=clamp(h,o.type==='table'?o.rows.length*28:32,20000);if(mode.includes('w'))o.x=clamp(original.x+original.w-o.w,0,1000-o.w);if(mode.includes('n'))o.y=Math.max(0,original.y+original.h-o.h);o.x=clamp(o.x,0,1000-o.w);
        if(o.type==='table'){o.cols=original.cols.map(v=>v*o.w/original.w);o.rows=original.rows.map(v=>v*o.h/original.h);this.refreshBody();}
      }
      this.update();this.onChange();updateStatus();updateGeometryFields(o);
    };
    const up=()=>{window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',up);$$('.st-guide',this.layer).forEach(g=>g.hidden=true);this.changed();renderInspector();};
    window.addEventListener('pointermove',move);window.addEventListener('pointerup',up,{once:true});
  }
  cropMode(){
    const o=this.item;if(o?.type!=='image')return;if(this.crop){this.crop=null;this.refreshBody();renderInspector();this.changed();return;}
    checkpoint();this.crop=o.id;const body=$(`[data-object-id="${o.id}"] .st-object-body`,this.layer);body.innerHTML=`<div class="st-crop-work"><img src="${esc(asset(o.url))}" draggable="false" alt="裁剪原图预览"><div class="st-crop-selection">${['nw','n','ne','e','se','s','sw','w'].map(p=>`<span class="st-crop-handle st-handle-${p}" data-crop="${p}"></span>`).join('')}</div></div>`;
    const box=$('.st-crop-selection',body);const place=()=>{const c=o.crop;box.style.inset=`${c.top*100}% ${c.right*100}% ${c.bottom*100}% ${c.left*100}%`;};place();
    body.onpointerdown=e=>{const grip=e.target.closest('[data-crop]');if(!grip)return;e.preventDefault();e.stopPropagation();const start={x:e.clientX,y:e.clientY},before=copy(o.crop),mode=grip.dataset.crop;
      const move=event=>{const dx=(event.clientX-start.x)/(o.w*this.scale),dy=(event.clientY-start.y)/(o.h*this.scale);if(mode.includes('w'))o.crop.left=clamp(before.left+dx,0,.9-o.crop.right);if(mode.includes('e'))o.crop.right=clamp(before.right-dx,0,.9-o.crop.left);if(mode.includes('n'))o.crop.top=clamp(before.top+dy,0,.9-o.crop.bottom);if(mode.includes('s'))o.crop.bottom=clamp(before.bottom-dy,0,.9-o.crop.top);place();this.onChange();};
      const up=()=>{window.removeEventListener('pointermove',move);this.changed();};window.addEventListener('pointermove',move);window.addEventListener('pointerup',up,{once:true});
    };renderInspector();
  }
}
/* Flow modules keep their real footprint in the website's original containers. */
class FlowSurface {
  constructor(host,layout,editable,onChange,kind='page'){
    Object.assign(this,{host,layer:host,layout,editable,onChange,kind,selected:null,crop:null,scale:1,containers:new Map(),modules:new Map(),owner:uid(),current:null});
    layout.mode='flow';layout.flow||={};host.classList.add('fm-surface');host.classList.toggle('fm-editable',editable);
    const path=el=>{const parts=[];for(let n=el;n&&n!==host;n=n.parentElement)parts.unshift(n.tagName.toLowerCase()+':'+[...n.parentElement.children].indexOf(n));return parts.join('/');};
    const candidates=kind==='page'?[host,...$$('.section,.workspace,.map-grid,.nodes-grid,.bottom-panels,.journal-list,.about-layout,.connection-layout,.hero,.actions,.hero-bottom,.page-top,.page-title-row,.section-heading,.section-heading>div,.map-copy,.about-card,.feature>div:first-child,.scope-card,.connection-layout>div:first-child,.node-card',host),...Array.from(host.children).filter(el=>!el.className&&el.tagName==='DIV')]:[host];
    const unique=[...new Set(candidates)].filter(el=>!el.closest('.st-inline-document')&&!el.matches('.section-note'));
    if(!unique.includes(host))unique.unshift(host);
    const definitions=unique.map(el=>{const card=el.matches('.node-card')?el:null;return {el,depth:path(el).split('/').length,key:el===host?'root':card?'container:node:'+card.dataset.id:'container:'+path(el),children:[...el.children].filter(v=>!v.matches('script,style,.st-inline-document,.st-inline-open,[data-flow-decoration]')).map((child,index)=>({child,ref:'base:'+(card?'node-part:'+card.dataset.id+':'+(child.matches('h2,h3')?'title':child.matches('p')?'summary':child.matches('.node-category')?'category':child.matches('.node-foot')?'footer':index):child.dataset.id?'node:'+child.dataset.id:path(child))}))};});
    for(const {el,key} of definitions){el.dataset.flowContainer=key;el.dataset.flowOwner=this.owner;this.containers.set(key,el);}
    for(const {el,children} of [...definitions].sort((a,b)=>b.depth-a.depth))for(const {child,ref} of children){const wrap=this.wrap(child,ref);el.insertBefore(wrap,child);wrap.append(child);}
    this.defaultContainer=[...this.containers.values()].find(el=>el.matches('.workspace:not(.feedback-layout),.section:not(.connection-layout)'))||host;
    this.paint();
    this.events=new AbortController();const opts={signal:this.events.signal};
    host.addEventListener('pointerdown',e=>this.pointerDown(e),opts);
    host.addEventListener('click',e=>this.click(e),opts);
    host.addEventListener('input',e=>{if(this.owns(e.target)){this.capture(e.target);this.changed();}},opts);
    host.addEventListener('focusin',e=>{if(this.owns(e.target)){const object=e.target.closest('.st-object');this.select(object?.dataset.objectId||null);this.current=e.target.closest('.fm-module');}},opts);
    host.addEventListener('paste',plainPaste,opts);
    host.addEventListener('keydown',e=>{if(this.editable&&this.owns(e.target)&&e.target.matches('.fm-tools [role="button"]')&&['Enter',' '].includes(e.key)){e.preventDefault();e.target.click();}},opts);
    this.observer=new ResizeObserver(()=>this.geometry());this.observer.observe(host);
  }
  owns(el){return el.closest('.fm-surface')===this.host;}
  wrap(child,ref){
    const wrap=document.createElement('div');wrap.className='fm-module';wrap.dataset.flowRef=ref;wrap.dataset.moduleOwner=this.owner;
    if(ref.startsWith('object:'))wrap.classList.add('fm-custom');
    if(child?.matches('h1,h2,h3,p,li,.actions,.button,.text-button,.status-pill,.section-note,.node-category,.node-foot,.hero-bottom>span'))wrap.classList.add('fm-fine');
    if(this.editable){const tools=document.createElement('div');tools.className='fm-tools';tools.contentEditable='false';const tag=child?.closest('button,a')?'span':'button',attributes=tag==='span'?'role="button" tabindex="0"':'type="button"';tools.innerHTML=[['drag','拖动板块','⠿'],['up','上移板块','↑'],['down','下移板块','↓'],['insert','在此板块后新建板块','＋']].map(([action,label,icon])=>`<${tag} ${attributes} data-module="${action}" aria-label="${label}" title="${label}">${icon}</${tag}>`).join('');wrap.append(tools);}
    this.modules.set(ref,wrap);return wrap;
  }
  destroy(){this.events?.abort();this.observer?.disconnect();this.cancelDrag?.();for(const wrap of this.modules.values()){if(wrap.dataset.flowRef.startsWith('object:'))wrap.remove();else{wrap.querySelector(':scope > .fm-tools')?.remove();wrap.replaceWith(...wrap.childNodes);}}for(const el of this.containers.values()){delete el.dataset.flowContainer;delete el.dataset.flowOwner;}this.host.classList.remove('fm-surface','fm-editable');}
  paint(){
    // Rebuild custom objects only; base page elements and their listeners stay intact.
    const sections=new Map();for(const o of this.layout.objects)if(o.type==='section'){const old=this.containers.get('section:'+o.id);if(old)sections.set(o.id,[...old.children].filter(el=>el.classList.contains('fm-module')));}
    for(const [ref,wrap] of this.modules)if(ref.startsWith('object:')){wrap.remove();this.modules.delete(ref);}
    for(const key of this.containers.keys())if(key.startsWith('section:'))this.containers.delete(key);
    for(const o of this.layout.objects){const wrap=this.wrap(null,'object:'+o.id);wrap.insertAdjacentHTML('beforeend',`<div class="fm-object-slot"><div class="st-object st-kind-${o.type}" data-flow-object-owner="${this.owner}" data-object-id="${o.id}"><div class="st-object-body">${bodyHTML(o,this.editable)}</div>${this.editable&&o.type!=='section'?controlsHTML(o):''}</div></div>`);this.defaultContainer.append(wrap);if(o.type==='section'){const container=$('[data-section-children]',wrap);container.dataset.flowContainer='section:'+o.id;container.dataset.flowOwner=this.owner;this.containers.set('section:'+o.id,container);}}
    const referenced=new Set();for(const [key,refs] of Object.entries(this.layout.flow)){const container=this.containers.get(key);if(!container)continue;for(const ref of refs){const wrap=this.modules.get(ref);if(wrap&&wrap!==container&&!wrap.contains(container)&&!referenced.has(ref)){container.append(wrap);referenced.add(ref);}}}
    this.addEmptyHints();this.geometry();this.select(this.selected,false);
  }
  addEmptyHints(){for(const container of this.containers.values()){container.querySelector(':scope > .fm-empty')?.remove();if(this.editable&&(container===this.host&&this.kind!=='page'||container.classList.contains('fm-section-children'))&&!container.querySelector(':scope > .fm-module')){const button=document.createElement('button');button.className='fm-empty';button.type='button';button.textContent='＋ 在这里插入内容';button.onclick=()=>{active=this;this.current=null;this.insertionContainer=container;$('#studioDock [data-st-tab="insert"]')?.click();};container.append(button);}}}
  sync(){for(const [key,container] of this.containers){const refs=[...container.children].filter(el=>el.dataset.moduleOwner===this.owner).map(el=>el.dataset.flowRef);const missing=(this.layout.flow[key]||[]).filter(ref=>!this.modules.has(ref));this.layout.flow[key]=[...refs,...missing];}}
  geometry(){
    for(const o of this.layout.objects){const wrap=this.modules.get('object:'+o.id);if(!wrap)continue;const slot=$(':scope > .fm-object-slot',wrap),node=$(':scope > .st-object',slot),natural=['text','section','file'].includes(o.type);const available=wrap.clientWidth||this.host.clientWidth||1000;
      node.style.cssText='';slot.style.cssText='';wrap.style.setProperty('--fm-align',o.placement==='left'?'flex-start':o.placement==='right'?'flex-end':'center');
      if(natural){node.style.width=Math.min(o.w,available)+'px';node.style.position='relative';node.style.height='auto';slot.style.width='100%';slot.style.display='flex';slot.style.justifyContent='var(--fm-align)';}
      else{const angle=(o.rotation||0)*Math.PI/180,bw=Math.abs(o.w*Math.cos(angle))+Math.abs(o.h*Math.sin(angle)),bh=Math.abs(o.w*Math.sin(angle))+Math.abs(o.h*Math.cos(angle)),scale=Math.min(1,available/bw);node.style.width=o.w+'px';node.style.height=o.h+'px';node.style.left=(bw-o.w)*scale/2+'px';node.style.top=(bh-o.h)*scale/2+'px';node.style.transformOrigin='top left';node.style.transform=`scale(${scale}) rotate(${o.rotation||0}deg)`;node.style.transformOrigin='center center';node.style.left=(bw*scale-o.w)/2+'px';node.style.top=(bh*scale-o.h)/2+'px';slot.style.width=bw*scale+'px';slot.style.height=bh*scale+'px';slot.dataset.objectScale=scale;}
    }
    const slot=this.item&&this.modules.get('object:'+this.item.id)?.querySelector('.fm-object-slot');this.scale=Number(slot?.dataset.objectScale)||1;
  }
  select(id,notify=true){this.selected=id;for(const node of $$('[data-flow-object-owner]',this.host))if(node.dataset.flowObjectOwner===this.owner)node.classList.toggle('st-selected',node.dataset.objectId===id);if(id)this.current=this.modules.get('object:'+id);this.geometry();if(notify&&this.editable){active=this;renderInspector();}}
  get item(){return this.layout.objects.find(o=>o.id===this.selected);}
  capture(el){const node=el.closest('[data-flow-object-owner]');if(node?.dataset.flowObjectOwner!==this.owner)return;const o=this.layout.objects.find(v=>v.id===node.dataset.objectId);if(!o)return;if(['text','section'].includes(o.type)){o.runs=readRuns($('.st-text',node));if(o.type==='section')o.title=$('.fm-section-title',node).textContent.slice(0,200);}if(o.type==='table')$$('[data-cell]',node).forEach(cell=>{const [r,c]=cell.dataset.cell.split(',').map(Number);o.cells[r][c].runs=readRuns(cell);});}
  captureAll(){for(const node of $$('[data-flow-object-owner]',this.host))if(node.dataset.flowObjectOwner===this.owner)this.capture(node);this.sync();}
  changed(){this.sync();this.onChange();this.geometry();this.addEmptyHints();updateStatus();}
  update(){this.geometry();}
  refreshBody(){const node=this.item&&this.modules.get('object:'+this.item.id)?.querySelector('.st-object-body');if(node)node.innerHTML=bodyHTML(this.item,this.editable);this.geometry();}
  add(o){if(this.layout.objects.length>=200)return status('每页最多 200 个模块。');this.captureAll();const currentRef=this.current?.dataset.flowRef;const parentKey=(this.insertionContainer||(this.item?.type==='section'?this.containers.get('section:'+this.item.id):this.current?.parentElement)||this.defaultContainer).dataset.flowContainer;this.insertionContainer=null;o.id=uid();this.layout.objects.push(o);this.paint();const wrap=this.modules.get('object:'+o.id),parent=this.containers.get(parentKey)||this.defaultContainer,current=this.modules.get(currentRef);if(current&&current.parentElement===parent)current.after(wrap);else parent.append(wrap);this.select(o.id);this.changed();wrap.scrollIntoView({behavior:'smooth',block:'center'});$('.st-text',wrap)?.focus({preventScroll:true});}
  move(wrap,delta){const siblings=[...wrap.parentElement.children].filter(el=>el.dataset.moduleOwner===this.owner),index=siblings.indexOf(wrap),target=siblings[index+delta];if(!target)return;this.animateMove(()=>delta<0?target.before(wrap):target.after(wrap));this.changed();}
  command(command){const o=this.item;if(!o){if(['front','back'].includes(command)&&this.current){checkpoint();this.move(this.current,command==='front'?-1:1);}return;}this.captureAll();checkpoint();if(command==='front'||command==='back'){this.move(this.modules.get('object:'+o.id),command==='front'?-1:1);return;}if(command==='copy'){const next=copy(o);if(o.type==='section')return status('请新建板块，再将内容拖入；板块内内容不会重复复制。');return this.add(next);}if(command==='remove'){const removed=new Set([o.id]);const collect=id=>{for(const ref of this.layout.flow['section:'+id]||[])if(ref.startsWith('object:')){removed.add(ref.slice(7));collect(ref.slice(7));}};collect(o.id);this.layout.objects=this.layout.objects.filter(v=>!removed.has(v.id));for(const key of Object.keys(this.layout.flow)){if(key.startsWith('section:')&&removed.has(key.slice(8)))delete this.layout.flow[key];else this.layout.flow[key]=this.layout.flow[key].filter(ref=>!removed.has(ref.slice(7)));}this.selected=null;this.current=null;this.crop=null;this.paint();this.changed();renderInspector();return;}
    // Table growth uses the existing geometry checks, then the flow footprint updates.
    if(command==='row'||command==='column'){Surface.prototype.command.call(this,command);}
  }
  click(e){if(!this.editable||!this.owns(e.target))return;const button=e.target.closest('[data-module]');if(button){e.preventDefault();e.stopPropagation();active=this;this.current=button.closest('.fm-module');const action=button.dataset.module;if(action==='insert'){this.select(null,false);checkpoint();insert({type:'section',title:'新板块',runs:plain('点击这里填写板块内容。',17),w:900,h:120});}else if(action==='up'||action==='down'){checkpoint();this.move(this.current,action==='up'?-1:1);}return;}const cmd=e.target.closest('[data-object-command]');if(cmd){e.preventDefault();this.select(cmd.closest('.st-object').dataset.objectId);this.command(cmd.dataset.objectCommand);}}
  pointerDown(e){if(!this.editable||e.button!==0||!this.owns(e.target))return;const wrap=e.target.closest('.fm-module');if(!wrap||wrap.dataset.moduleOwner!==this.owner)return;active=this;this.current=wrap;const node=e.target.closest('[data-flow-object-owner]');this.select(node?.dataset.flowObjectOwner===this.owner?node.dataset.objectId:null);this.current=wrap;
    if(e.target.closest('[data-module="drag"],.st-move')){e.preventDefault();e.stopPropagation();this.drag(e,wrap);return;}
    if(e.target.closest('[data-drag],[data-cell-resize]')){Surface.prototype.pointerDown.call(this,e);}
  }
  animateMove(change){const elements=[...this.modules.values()].filter(el=>el.isConnected),before=new Map(elements.map(el=>[el,el.getBoundingClientRect()]));change();if(matchMedia('(prefers-reduced-motion: reduce)').matches)return;for(const el of elements){const a=before.get(el),b=el.getBoundingClientRect(),dx=a.left-b.left,dy=a.top-b.top;if(dx||dy)el.animate([{transform:`translate(${dx}px,${dy}px)`},{transform:'translate(0,0)'}],{duration:180,easing:'ease-out'});}}
  drag(e,wrap){this.captureAll();checkpoint();const box=wrap.getBoundingClientRect(),ghost=wrap.cloneNode(true);ghost.querySelectorAll('.fm-tools').forEach(el=>el.remove());ghost.className='fm-drag-ghost';ghost.style.cssText=`position:fixed;width:${Math.min(box.width,500)}px;left:${e.clientX+16}px;top:${e.clientY+16}px`;document.body.append(ghost);wrap.classList.add('fm-drag-placeholder');document.body.classList.add('fm-dragging');let over=null;
    const move=event=>{ghost.style.left=event.clientX+16+'px';ghost.style.top=event.clientY+16+'px';const hit=document.elementFromPoint(event.clientX,event.clientY);if(!hit||wrap.contains(hit))return;let container=hit.closest('[data-flow-container]');if(container?.dataset.flowOwner!==this.owner||wrap.contains(container))return;const custom=wrap.dataset.flowRef.startsWith('object:');if(!custom&&container!==wrap.parentElement)return;over?.classList.remove('fm-drop-target');over=container;over.classList.add('fm-drop-target');const candidates=[...container.children].filter(el=>el.dataset.moduleOwner===this.owner&&el!==wrap),box=el=>{const r=el.getBoundingClientRect(),matrix=new DOMMatrix(getComputedStyle(el).transform);return {left:r.left-matrix.m41,top:r.top-matrix.m42,width:r.width,height:r.height};};let next=null;if(getComputedStyle(container).display==='grid'||getComputedStyle(container).display.includes('flex')&&!getComputedStyle(container).flexDirection.startsWith('column')){const target=candidates.reduce((best,el)=>{const r=box(el),distance=Math.hypot(event.clientX-r.left-r.width/2,event.clientY-r.top-r.height/2);return !best||distance<best.distance?{el,r,distance}:best;},null);if(target){const {el,r}=target,after=Math.abs(event.clientY-r.top-r.height/2)<r.height*.35?event.clientX>r.left+r.width/2:event.clientY>r.top+r.height/2;next=after?candidates[candidates.indexOf(el)+1]||null:el;}}else next=candidates.find(el=>{const r=box(el);return event.clientY<r.top+r.height/2;})||null;if(next!==wrap&&(wrap.nextElementSibling!==next||wrap.parentElement!==container))this.animateMove(()=>container.insertBefore(wrap,next));this.geometry();if(event.clientY>innerHeight-90)scrollBy(0,18);else if(event.clientY<210)scrollBy(0,-18);};
    const finish=()=>{window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',finish);window.removeEventListener('pointercancel',cancel);ghost.remove();wrap.classList.remove('fm-drag-placeholder');over?.classList.remove('fm-drop-target');document.body.classList.remove('fm-dragging');this.cancelDrag=null;this.changed();};const originalParent=wrap.parentElement,originalNext=wrap.nextSibling;const cancel=()=>{originalParent.insertBefore(wrap,originalNext?.parentElement===originalParent?originalNext:null);finish();};this.cancelDrag=cancel;window.addEventListener('pointermove',move);window.addEventListener('pointerup',finish,{once:true});window.addEventListener('pointercancel',cancel,{once:true});
  }
  refreshGrid(grid){
    if(grid.dataset.flowOwner!==this.owner)return;const key=grid.dataset.flowContainer;
    for(const [ref,wrap] of this.modules)if(!wrap.isConnected&&/^base:node(?:-part)?:/.test(ref))this.modules.delete(ref);
    for(const [key,container] of this.containers)if(key.startsWith('container:node:')&&!container.isConnected)this.containers.delete(key);
    for(const card of [...grid.children].filter(el=>el.classList.contains('node-card'))){const ref='base:node:'+card.dataset.id,wrap=this.wrap(card,ref);grid.insertBefore(wrap,card);wrap.append(card);const key='container:node:'+card.dataset.id;card.dataset.flowContainer=key;card.dataset.flowOwner=this.owner;this.containers.set(key,card);for(const [index,child] of [...card.children].entries()){if(child.matches('.st-inline-open'))continue;const field=child.matches('h2,h3')?'title':child.matches('p')?'summary':child.matches('.node-category')?'category':child.matches('.node-foot')?'footer':index,part=this.wrap(child,'base:node-part:'+card.dataset.id+':'+field);card.insertBefore(part,child);part.append(child);}for(const partRef of this.layout.flow[key]||[]){const part=this.modules.get(partRef);if(part?.parentElement===card)card.append(part);}}
    const refs=this.layout.flow[key]||[];for(const ref of refs){const wrap=this.modules.get(ref);if(wrap&&(wrap.parentElement===grid||ref.startsWith('object:')))grid.append(wrap);}this.geometry();
  }
  cropMode(){return Surface.prototype.cropMode.call(this);}
}
function plainPaste(event){if(event.defaultPrevented||!event.target.closest('[contenteditable]'))return;event.preventDefault();document.execCommand('insertText',false,event.clipboardData.getData('text/plain'));}

function context(){return active?.kind==='document'&&docSession?docSession:pageSession;}
function checkpoint(){
  const ctx=context();if(!ctx)return;active?.captureAll();
  const snapshot=JSON.stringify(ctx.kind==='document'?{node:ctx.node,layout:ctx.layout}:{layouts:ctx.layouts,pageTexts:ctx.pageTexts,nodeEdits:ctx.nodeEdits||{}});
  if(ctx.history.at(-1)!==snapshot){ctx.history.push(snapshot);if(ctx.history.length>60)ctx.history.shift();}ctx.future=[];
}
function changed(){const ctx=context();if(ctx)ctx.dirty=true;updateStatus();}
function updateStatus(){const el=$('#studioDock .st-save-state');if(el)el.textContent=pageSession?.dirty||docSession?.dirty?'未保存':'已保存';}
function undo(redo=false){
  const ctx=context();if(!ctx)return;const from=redo?ctx.future:ctx.history,to=redo?ctx.history:ctx.future;if(!from.length)return status(redo?'没有可重做的操作。':'没有可撤销的操作。');
  active?.captureAll();to.push(JSON.stringify(ctx.kind==='document'?{node:ctx.node,layout:ctx.layout}:{layouts:ctx.layouts,pageTexts:ctx.pageTexts,nodeEdits:ctx.nodeEdits||{}}));Object.assign(ctx,JSON.parse(from.pop()));ctx.dirty=true;selection=null;textTarget=null;
  if(ctx.kind==='document'){ctx.surface.destroy();mountInlineDocument(ctx);}else config.render();updateStatus();renderInspector();
}
function preserveSelection(){
  const s=window.getSelection();if(!s.rangeCount)return;const node=s.anchorNode?.nodeType===1?s.anchorNode:s.anchorNode?.parentElement;
  const root=node?.closest('.st-text,.st-cell,[data-st-text-key]');
  if(root&&root.isContentEditable&&(root.contains(document.activeElement)||document.activeElement===root)&&(!selectionLocked||!s.isCollapsed)){selection=s.getRangeAt(0).cloneRange();textTarget=root;}
}
function restoreSelection(){if(!selection||!selection.commonAncestorContainer.isConnected||!textTarget?.isConnected)return false;const r=selection.cloneRange();textTarget.focus();const s=window.getSelection();s.removeAllRanges();s.addRange(r);selection=r;return true;}
function recordText(){
  if(!textTarget?.isConnected)return;
  if(textTarget.dataset.stTextKey){
    const fields=pageSession.pageTexts[view]||(pageSession.pageTexts[view]={});fields[textTarget.dataset.stTextKey]={runs:readRuns(textTarget),align:textTarget.style.textAlign||getComputedStyle(textTarget).textAlign||'left'};
    const [prefix,id,field]=textTarget.dataset.stTextKey.split(':');
    if(prefix==='node'&&['title','summary','category','status'].includes(field)){
      const value=textTarget.innerText.trim();((pageSession.nodeEdits||(pageSession.nodeEdits={}))[id]||(pageSession.nodeEdits[id]={}))[field]=value;
      if(docSession?.node.id===id){docSession.node[field]=value;const el=field==='title'?$('[data-node-title]',docSession.dialog):field==='summary'?$('[data-node-summary]',docSession.dialog):$(`[data-node-field="${field}"]`,docSession.dialog);if(el){if(el.isContentEditable)el.textContent=value;else el.value=value;}}
    }
    pageSession.dirty=true;updateStatus();return;
  }else active?.capture(textTarget);
  changed();
}
function format(kind,value){
  if(!context())return;checkpoint();
  if(!restoreSelection())return status('先点击页面文字或文本框，选中文字后再设置样式。');
  if(['bold','italic','underline'].includes(kind)){document.execCommand(kind);recordText();return;}
  if(kind==='align'){
    textTarget.style.textAlign=value;
    if(textTarget.dataset.cell&&active?.item?.type==='table'){const [r,c]=textTarget.dataset.cell.split(',').map(Number);active.item.cells[r][c].align=value;}
    else if(active?.item?.type==='text'&&active.layer.contains(textTarget))active.item.align=value;
    recordText();return;
  }
  const props={font:'fontFamily',size:'fontSize',color:'color',highlight:'backgroundColor'},property=props[kind];
  const range=selection.cloneRange(),span=document.createElement('span');
  if(kind==='gradient'){
    span.dataset.gradient=value;if(gradients[value]){span.className='st-gradient';span.style.setProperty('--st-gradient',gradients[value]);}
  }else if(property){span.style[property]=kind==='size'?clamp(Number(value),8,120)+'px':kind==='font'&&value==='system'?'inherit':value;}
  else return;
  if(range.collapsed){span.textContent='\u200b';range.insertNode(span);range.selectNodeContents(span);range.collapse(false);}
  else{
    const fragment=range.extractContents();fragment.querySelectorAll('*').forEach(el=>{
      if(property)el.style[property]='';
      if(kind==='color'||kind==='gradient'){el.classList.remove('st-default','st-gradient','document-default-color');el.removeAttribute('data-gradient');el.style.removeProperty('--st-gradient');}
      if(kind==='font')el.removeAttribute('face');if(kind==='size')el.removeAttribute('size');if(kind==='color')el.removeAttribute('color');
    });span.append(fragment);range.insertNode(span);range.selectNodeContents(span);
  }
  const s=window.getSelection();s.removeAllRanges();s.addRange(range);selection=range.cloneRange();recordText();
}
function ribbonHTML(){return `<div class="st-floating-toolbar" role="toolbar" aria-label="页面排版工具栏"><div class="st-toolbar-nav"><div class="st-toolbar-tabs"><button class="st-tab active" data-st-tab="start" type="button">开始</button><button class="st-tab" data-st-tab="insert" type="button">插入</button><button class="st-tab" data-st-tab="image" type="button">图片格式</button></div><div class="st-quick-actions"><button data-st="undo" title="撤销" aria-label="撤销">↶</button><button data-st="redo" title="重做" aria-label="重做">↷</button></div><span class="st-toolbar-spacer"></span><span class="st-save-state">已保存</span><button class="st-primary" data-st="save">保存</button><button class="st-finish" data-st="exit">完成编辑</button></div><div class="st-toolbar-panel" data-st-panel="start"><select data-format="font" aria-label="字体">${Object.entries(fonts).map(([v,t])=>`<option value="${v}">${t}</option>`).join('')}</select><input type="number" value="16" min="8" max="120" data-format="size" aria-label="字号"><button data-format="bold" title="粗体"><b>B</b></button><button data-format="italic" title="斜体"><i>I</i></button><button data-format="underline" title="下划线"><u>U</u></button><label title="文字颜色">字色<input type="color" value="#0071e3" data-format="color" aria-label="文字颜色"></label><label title="文字高亮">高亮<input type="color" value="#fff09a" data-format="highlight" aria-label="文字高亮"></label><select data-format="gradient" aria-label="文字渐变">${Object.entries(gradientNames).map(([v,t])=>`<option value="${v}">${t}</option>`).join('')}</select><span class="st-toolbar-divider"></span>${[['left','左对齐','☰'],['center','居中','≡'],['right','右对齐','☷'],['justify','两端对齐','▤']].map(([v,t,i])=>`<button data-text-align="${v}" title="${t}" aria-label="文字${t}">${i}</button>`).join('')}<button data-st="reset-text">恢复原文</button></div><div class="st-toolbar-panel" data-st-panel="insert" hidden><span class="st-table-picker-anchor"><button data-st="table">▦ 表格 ▾</button><div class="st-table-picker" hidden></div></span><button data-st="image">▧ 图片</button><button data-st="section">＋ 新建板块</button><button data-st="text">文字</button><button data-st="chart">▥ 图表</button><button data-st="file">▤ 附件</button><span class="st-toolbar-divider"></span><button data-st="center-object">对象居中</button><button data-st="front">向前移动</button><button data-st="back">向后移动</button><button data-st="copy">复制</button></div><div class="st-toolbar-panel" data-st-panel="image" hidden><button data-st="crop">⌗ 裁剪 / 完成</button><button data-st="reset-crop">还原裁剪</button><select data-object-style="border" aria-label="图片边框"><option value="none">无边框</option><option value="solid">实线边框</option><option value="dashed">虚线边框</option><option value="soft">柔和阴影</option></select><label>边缘虚化<input type="range" min="0" max="50" value="0" data-object-style="feather" aria-label="图片边缘虚化"></label><button data-st="center-object">对象居中</button></div></div>`;}
function bindRibbon(root){
  $$('[data-st-tab]',root).forEach(button=>button.onclick=()=>{const tab=button.dataset.stTab;$$('[data-st-tab]',root).forEach(b=>b.classList.toggle('active',b===button));$$('[data-st-panel]',root).forEach(panel=>panel.hidden=panel.dataset.stPanel!==tab);$$('.st-table-picker',root).forEach(box=>box.hidden=true);});
  root.addEventListener('pointerdown',event=>{if(event.target.closest('[data-format],[data-text-align]')){preserveSelection();selectionLocked=true;}},true);
  $$('button[data-format],button[data-text-align]',root).forEach(b=>b.addEventListener('pointerdown',e=>e.preventDefault()));
  $$('[data-format]',root).forEach(control=>{
    if(control.tagName==='BUTTON')control.onclick=()=>format(control.dataset.format);
    else control.addEventListener(control.type==='color'||control.type==='number'?'input':'change',()=>format(control.dataset.format,control.value));
  });
  $$('[data-text-align]',root).forEach(b=>b.onclick=()=>format('align',b.dataset.textAlign));
  $$('[data-object-style]',root).forEach(control=>control.addEventListener(control.type==='range'?'input':'change',()=>{
    if(active?.item?.type!=='image')return status('请先选择一张图片。');checkpoint();active.item[control.dataset.objectStyle]=control.type==='range'?Number(control.value):control.value;active.refreshBody();active.changed();renderInspector();
  }));
  $$('[data-st]',root).forEach(b=>b.onclick=()=>{
    const action=b.dataset.st;
    if(action==='undo')return undo();if(action==='redo')return undo(true);
    if(action==='save')return saveAll();
    if(action==='exit')return exitPage();
    if(action==='table')return tablePicker($('.st-table-picker',root));
    if(action==='image'||action==='file')return upload(action==='image');
    if(action==='section'){checkpoint();return insert({type:'section',title:'新板块',runs:plain('点击这里填写板块内容。',17),w:900,h:120});}
    if(action==='text'){checkpoint();return insert({type:'text',runs:plain('在这里输入文字…',24),w:360,h:100});}
    if(action==='chart')return chartForm();
    if(action==='reset-text'){
      if(!textTarget?.dataset.stTextKey)return status('先选择需要恢复的页面文字。');checkpoint();delete pageSession.pageTexts[view]?.[textTarget.dataset.stTextKey];changed();config.render();return;
    }
    if(action==='crop')return active?.cropMode();
    if(action==='reset-crop'){if(active?.item?.type!=='image')return;checkpoint();active.item.crop={left:0,right:0,top:0,bottom:0};active.crop=null;active.refreshBody();active.changed();return;}
    if(action==='center-object'){if(!active?.item)return status('请先选择一个对象。');checkpoint();active.item.placement='center';active.item.x=(1000-active.item.w)/2;active.update();active.changed();renderInspector();return;}
    active?.command(action);
  });
}
function tablePicker(box){
  box.hidden=!box.hidden;if(box.hidden)return;let rows=2,cols=2;
  const anchor=box.parentElement.getBoundingClientRect();box.style.left=clamp(anchor.left,12,Math.max(12,innerWidth-310))+'px';box.style.top=anchor.bottom+8+'px';
  function draw(){box.innerHTML=`<strong>选择表格格数</strong><p class="st-grid-size">2 × 2</p><div class="st-picker-grid" style="grid-template-columns:repeat(${cols},20px)">${Array.from({length:rows},(_,r)=>Array.from({length:cols},(_,c)=>`<button type="button" data-grid="${r+1},${c+1}" aria-label="${r+1} 行 ${c+1} 列"></button>`).join('')).join('')}</div><div class="st-picker-actions"><button data-grid-expand="row" aria-label="扩展表格选择行数">＋ 行</button><button data-grid-expand="column" aria-label="扩展表格选择列数">＋ 列</button></div><button class="st-primary" data-default-grid>插入 2 × 2 表格</button>`;
    $$('[data-grid]',box).forEach(b=>{b.onpointerenter=()=>{const [r,c]=b.dataset.grid.split(',').map(Number);$('.st-grid-size',box).textContent=`${c} × ${r}`;$$('[data-grid]',box).forEach(v=>{const [rr,cc]=v.dataset.grid.split(',').map(Number);v.classList.toggle('st-grid-active',rr<=r&&cc<=c);});};b.onclick=()=>{const [r,c]=b.dataset.grid.split(',').map(Number);create(r,c);};});
    $('[data-grid-expand="row"]',box).onclick=()=>{rows=Math.min(10,rows+1);draw();};$('[data-grid-expand="column"]',box).onclick=()=>{cols=Math.min(12,cols+1);draw();};$('[data-default-grid]',box).onclick=()=>create(2,2);
  }
  function create(r,c){checkpoint();insert({type:'table',cells:Array.from({length:r},()=>Array.from({length:c},()=>({runs:plain(''),align:'left'}))),cols:Array(c).fill(Math.min(140,800/c)),rows:Array(r).fill(48),w:Math.min(140*c,800),h:48*r,header:true,borderColor:'#b8c3d5'});box.hidden=true;}
  draw();
}
function insert(data){
  if(!active?.editable)return status('请先进入编辑模式。');const surface=active;if(surface instanceof FlowSurface){surface.add({x:0,y:0,rotation:0,align:'left',placement:'center',...data});return;}const rect=surface.host.getBoundingClientRect();
  const anchor=surface.anchor||{x:500,y:Math.max(100,(Math.min(innerHeight-150,Math.max(150,rect.top+260))-rect.top)/surface.scale)};
  surface.add({x:clamp(anchor.x-(data.w||300)/2,24,Math.max(24,976-(data.w||300))),y:clamp(anchor.y,24,29000),rotation:0,align:'left',...data});surface.anchor={x:anchor.x,y:anchor.y+(data.h||100)+35};
}
async function upload(image){
  const ctx=context(),surface=active;if(!ctx||!surface)return;const input=document.createElement('input');input.type='file';input.hidden=true;input.accept=image?'.png,.jpg,.jpeg,.webp,.gif':'.pdf,.txt,.csv,.docx,.xlsx,.pptx,.zip';(docSession?.dialog||document.body).append(input);
  input.oncancel=()=>input.remove();input.onchange=async()=>{
    try{
      const file=input.files[0];if(!file)return;if(file.size>10*1024*1024)throw new Error('单个文件最多 10 MB。');status('正在上传到本地项目…');
      const response=await fetch('api/upload',{method:'POST',headers:{'Content-Type':'application/octet-stream','X-File-Name':encodeURIComponent(file.name)},body:file});const result=await response.json();if(!response.ok)throw new Error(result.error||'上传失败。');if(context()!==ctx)return;
      active=surface;checkpoint();let w=400,h=260;
      if(image){const picture=new Image();await new Promise((resolve,reject)=>{picture.onload=resolve;picture.onerror=()=>reject(new Error('图片无法解码。'));picture.src=asset(result.url);});w=Math.min(480,Math.max(160,picture.naturalWidth));h=clamp(w*picture.naturalHeight/picture.naturalWidth,80,700);}
      insert({...result,type:image?'image':'file',w:image?w:380,h:image?h:86,crop:{left:0,top:0,right:0,bottom:0},border:'none',borderWidth:1,borderColor:'#b9c7db',radius:0,feather:0});status('已插入内容模块。拖动板块六点手柄排序，内容会自动让位。');
    }catch(error){status(error.message);}finally{input.remove();}
  };input.click();
}
function popup(title,html,submit){
  const dialog=document.createElement('dialog');dialog.className='st-popup';dialog.innerHTML=`<form><div class="dialog-heading"><h2>${esc(title)}</h2><button type="button" class="close" aria-label="关闭设置">×</button></div>${html}<p class="form-error"></p><div class="form-actions"><button type="button" class="button secondary" data-cancel>取消</button><button type="submit" class="button">确定</button></div></form>`;document.body.append(dialog);dialog.showModal();
  const close=()=>{dialog.close();dialog.remove();};$('.close',dialog).onclick=close;$('[data-cancel]',dialog).onclick=close;dialog.oncancel=e=>{e.preventDefault();close();};$('form',dialog).onsubmit=e=>{e.preventDefault();try{submit(new FormData(e.currentTarget));close();}catch(error){$('.form-error',dialog).textContent=error.message;}};
}
function chartForm(existing){
  popup(existing?'编辑图表数据':'插入图表',`<label class="field">图表标题<input name="title" maxlength="100" value="${esc(existing?.title||'请输入图表标题')}" required></label><label class="field">图表类型<select name="chartType"><option value="bar">条形图</option><option value="column" ${existing?.chartType==='column'?'selected':''}>柱状图</option></select></label><label class="field">数据：每行「名称 | 数值」<textarea name="values" required>${esc(existing?.values.map(v=>v.label+' | '+v.value).join('\n')||'项目 A | 0\n项目 B | 0')}</textarea><small>请填写真实数值，并在正文说明单位与来源。</small></label>`,data=>{
    const values=data.get('values').split('\n').filter(v=>v.trim()).map(row=>{const [label,num]=row.split('|').map(v=>v.trim());const value=Number(num);if(!label||num===undefined||num===''||!Number.isFinite(value)||value<0||value>1e9)throw new Error('数值需为 0–10 亿之间的数字。');return {label,value};});if(!values.length||values.length>20)throw new Error('请填写 1–20 组数据。');checkpoint();
    if(existing){Object.assign(existing,{title:data.get('title'),values,chartType:data.get('chartType')});active.refreshBody();active.changed();}else insert({type:'chart',title:data.get('title'),values,chartType:data.get('chartType'),color:'#508de0',w:500,h:320});
  });
}

function inspectorRoot(){return $('#studioInspector');}
function renderInspector(){
  const root=inspectorRoot();if(!root)return;const o=active?.item;
  root.hidden=!o;if(!o)return;
  const names={text:'文字模块',section:'内容板块',image:'图片',table:'表格',chart:'图表',file:'附件'};
  root.innerHTML=`<div class="st-inspector-title">${names[o.type]}属性 <span>${Math.round(o.w)} × ${Math.round(o.h)}</span></div><div class="st-inspector-grid">${(['text','section','file'].includes(o.type)?[['w','宽度']]:[['w','宽度'],['h','高度'],['rotation','旋转角度']]).map(([k,t])=>`<label>${t}<input type="number" data-geometry="${k}" value="${Math.round(o[k]||0)}" step="1" aria-label="${t}"></label>`).join('')}</div><div class="st-inspector-buttons"><button data-command="copy">复制</button><button data-command="remove">删除</button><button data-command="front">前移</button><button data-command="back">后移</button></div>${o.type==='image'?`<div class="st-inspector-section"><h4>图片格式</h4><label>边框<select data-image="border">${[['none','无边框'],['solid','实线'],['dashed','虚线'],['soft','柔和阴影']].map(([v,t])=>`<option value="${v}" ${o.border===v?'selected':''}>${t}</option>`).join('')}</select></label><label>边框颜色<input type="color" value="${o.borderColor||'#b9c7db'}" data-image="borderColor"></label><label>线宽<input type="number" min="0" max="16" value="${o.borderWidth||1}" data-image="borderWidth"></label><label>圆角<input type="range" min="0" max="100" value="${o.radius||0}" data-image="radius"></label><label>边缘虚化<input type="range" min="0" max="50" value="${o.feather||0}" data-image="feather"></label><button class="st-inspector-action" data-crop-button>${active.crop?'完成裁剪':'裁剪图片'}</button><p>${active.crop?'拖动图片内的黑色裁剪控点，完成后再次点击上方按钮。':'裁剪保留原图，可随时还原。拖动四角默认保持比例，按住 Shift 可自由缩放。'}</p><label>图片说明<input type="text" maxlength="500" value="${esc(o.caption||'')}" data-image="caption"></label></div>`:''}${o.type==='table'?`<div class="st-inspector-section"><h4>${o.cells.length} 行 × ${o.cols.length} 列</h4><div class="st-inspector-buttons"><button data-command="row">＋ 一行</button><button data-command="column">＋ 一列</button></div><p>拖动单元格右下角的小方块，可同时调整对应行高与列宽。表格右边和底边的 ＋ 可继续扩展。</p><label>首行为表头<input type="checkbox" data-table-header ${o.header?'checked':''}></label></div>`:''}${o.type==='chart'?'<div class="st-inspector-section"><button class="st-inspector-action" data-chart-edit>编辑图表数据</button></div>':''}`;
  $$('[data-geometry]',root).forEach(input=>input.oninput=()=>{
    const key=input.dataset.geometry,value=Number(input.value);if(!Number.isFinite(value))return;checkpoint();
    if(key==='x')o.x=clamp(value,0,Math.max(0,1000-o.w));else if(key==='y')o.y=clamp(value,0,29000);else if(key==='rotation')o.rotation=clamp(value,-36000,36000);
    else if(key==='w'){const before=o.w;o.w=clamp(value,o.type==='table'?o.cols.length*32:40,1000);o.x=Math.min(o.x,1000-o.w);if(o.type==='table')o.cols=o.cols.map(v=>v*o.w/before);}
    else{const before=o.h;o.h=clamp(value,o.type==='table'?o.rows.length*28:24,20000);if(o.type==='table')o.rows=o.rows.map(v=>v*o.h/before);}
    active.update();if(o.type==='table')active.refreshBody();active.changed();
  });
  $$('[data-command]',root).forEach(b=>b.onclick=()=>active.command(b.dataset.command));
  $$('[data-image]',root).forEach(input=>input.addEventListener(input.type==='range'||input.type==='color'?'input':'change',()=>{checkpoint();o[input.dataset.image]=['range','number'].includes(input.type)?Number(input.value):input.value;active.refreshBody();active.changed();}));
  $('[data-crop-button]',root)?.addEventListener('click',()=>active.cropMode());
  $('[data-chart-edit]',root)?.addEventListener('click',()=>chartForm(o));
  $('[data-table-header]',root)?.addEventListener('change',event=>{checkpoint();o.header=event.target.checked;active.refreshBody();active.changed();});
}
function updateGeometryFields(o){const root=inspectorRoot();if(root)$$('[data-geometry]',root).forEach(input=>{if(input!==document.activeElement)input.value=Math.round(o[input.dataset.geometry]||0);});}
function textKey(el,main){
  const card=el.closest('[data-action="node"][data-id]');if(card){const field=el.matches('h2,h3')?'title':el.matches('p')?'summary':el.classList.contains('node-category')?'category':el.classList.contains('badge')?'status':el.tagName.toLowerCase()+':'+[...el.parentElement.children].indexOf(el);return 'node:'+card.dataset.id+':'+field;}
  const parts=[];for(let n=el;n&&n!==main;n=n.parentElement){const index=[...n.parentElement.children].filter(v=>v.tagName===n.tagName).indexOf(n);parts.unshift(n.tagName.toLowerCase()+':'+index);}return parts.join('/');
}
function prepareText(main,overrides,editable){
  const targets=$$('h1,h2,h3,p,li,.status-pill,.node-category,.hero-bottom>span,.art-label,.path-row strong,.path-row small,.button,.text-button,.section-note,.map-card-bottom>span,.node-foot>span',main).filter(el=>!el.closest('.st-layer,form,.feedback-card,[data-action="new-node"],[data-action="settings"],[data-action="export-feedback"]')&&!el.querySelector('input,select,textarea,button,h1,h2,h3,p,li')&&el.textContent.trim());
  for(const el of targets){
    const key=textKey(el,main);baseOriginals.set(el,{html:el.innerHTML,align:el.style.textAlign});
    if(Object.hasOwn(overrides,key)){el.innerHTML=runsHTML(overrides[key].runs);el.style.textAlign=overrides[key].align;}
    if(editable){el.dataset.stTextKey=key;el.contentEditable='true';el.spellcheck=false;el.setAttribute('aria-label','编辑页面文字');}
  }
}
function page(){
  const main=$('#main');pageSurface?.destroy();pageSurface=null;view=location.hash.slice(1).split('?')[0]||'home';if(!views[view])view='home';
  if(docSession?.surface){docSession.surface.destroy();docSession.dialog?.remove();}
  let dock=$('#studioDock');if(!dock){dock=document.createElement('div');dock.id='studioDock';main.before(dock);}
  let inspector=$('#studioInspector');if(!inspector){inspector=document.createElement('aside');inspector.id='studioInspector';inspector.className='st-inspector st-page-inspector';document.body.append(inspector);}
  const admin=config.isAdmin();if(!admin){pageSession=null;docSession=null;editingPaused=false;}
  if(admin&&!pageSession&&!editingPaused)pageSession={kind:'page',revision:config.getSite().revision,layouts:copy(config.getSite().layouts||{}),pageTexts:copy(config.getSite().pageTexts||{}),dirty:false,history:[],future:[]};
  if(pageSession&&!pageSession.dirty){pageSession.revision=config.getSite().revision;pageSession.layouts=copy(config.getSite().layouts||{});pageSession.pageTexts=copy(config.getSite().pageTexts||{});pageSession.nodeEdits={};}
  const editing=!!pageSession,site=config.getSite(),layouts=editing?pageSession.layouts:site.layouts||{},texts=editing?pageSession.pageTexts:site.pageTexts||{};
  dock.hidden=!admin;dock.className=editing?'st-dock st-dock-editing':'st-dock';inspector.hidden=!editing;main.classList.toggle('st-page-editing',editing);document.body.classList.toggle('st-page-editing-body',editing);
  if(admin){dock.innerHTML=editing?ribbonHTML():`<div class="st-mini-dock"><button class="st-primary" id="startPageStudio">✎ 编辑页面</button></div>`;if(editing)bindRibbon(dock);else $('#startPageStudio').onclick=enterPage;}
  prepareText(main,texts[view]||{},editing);
  const layout=layouts[view]||(editing?(layouts[view]={height:400,objects:[]}):{height:200,objects:[]});
  // Plain visitor pages need neither edit wrappers nor their resize observer.
  // Saved module orders and inserted content still use the full flow renderer.
  if(editing||layout.objects.length||Object.keys(layout.flow||{}).length)pageSurface=new FlowSurface(main,layout,editing,changed,'page');
  if(!docSession)active=pageSurface;
  main.onpointerdown=event=>{
    if(!pageSession||event.target.closest('.fm-module,.st-inline-document'))return;active=pageSurface;
    const rect=main.getBoundingClientRect();pageSurface.anchor={x:clamp((event.clientX-rect.left)/pageSurface.scale,24,976),y:Math.max(24,(event.clientY-rect.top)/pageSurface.scale)};
    pageSurface.select(null);if(!event.target.closest('[data-st-text-key]')){selection=null;textTarget=null;}
  };
  main.oninput=event=>{if(pageSession&&event.target.closest('[data-st-text-key]')){textTarget=event.target.closest('[data-st-text-key]');recordText();}};
  main.onfocusin=event=>{if(pageSession&&event.target.closest('[data-st-text-key]')&&!event.target.closest('.st-inline-document'))active=pageSurface;};
  main.onbeforeinput=()=>{if(pageSession&&Date.now()-(pageSession.lastTextCheckpoint||0)>650){checkpoint();pageSession.lastTextCheckpoint=Date.now();}};
  main.onpaste=plainPaste;fitViews(main);if(docSession)mountInlineDocument(docSession);if(editing){renderInspector();updateStatus();}
  refreshCards();
}
function refreshCards(){const grid=$('#nodeGrid');if(!grid)return;if(pageSession){prepareText(grid,pageSession.pageTexts[view]||{},true);$$('.node-card',grid).forEach(card=>{if(!$('.st-inline-open',card))card.insertAdjacentHTML('beforeend','<span class="st-inline-open">编辑正文 ↗</span>');});}pageSurface?.refreshGrid?.(grid);}
function enterPage(){
  editingPaused=false;pageSession={kind:'page',revision:config.getSite().revision,layouts:copy(config.getSite().layouts||{}),pageTexts:copy(config.getSite().pageTexts||{}),dirty:false,history:[],future:[]};config.render();
  status('点击文字编辑；拖动板块左上角的六点手柄排序，＋ 可在后面插入新板块。');
}
async function savePage(){
  if(!pageSession)return true;pageSurface?.captureAll();const next=copy(config.getSite());next.revision=pageSession.revision;next.layouts=copy(pageSession.layouts);next.pageTexts=copy(pageSession.pageTexts);
  for(const node of next.nodes)if(pageSession.nodeEdits?.[node.id])Object.assign(node,pageSession.nodeEdits[node.id]);
  const buttons=$$('[data-st="save"]');buttons.forEach(b=>b.disabled=true);
  try{const result=await config.save(next);pageSession.revision=result.revision;pageSession.dirty=false;pageSession.nodeEdits={};docSession?.options.rebase?.();updateStatus();status('页面文字、对象和排版已保存到本地。');return true;}catch(error){status(error.message);return false;}finally{buttons.forEach(b=>b.disabled=false);}
}
async function saveAll(){if(pageSession?.dirty&&!(await savePage()))return false;if(docSession?.dirty&&!(await saveDocument()))return false;updateStatus();status('已保存到本地。');return true;}
function exitPage(){if((pageSession?.dirty||docSession?.dirty)&&!confirm('还有未保存的修改。确定放弃并退出编辑吗？'))return;if(docSession){docSession.surface.destroy();docSession.dialog.remove();docSession=null;}editingPaused=true;pageSession=null;selection=null;textTarget=null;config.render();}
function legacyLayout(node){
  let y=50;const objects=[];
  for(const block of node.blocks||[]){
    const id=uid(),base={id,x:50,y,w:900,h:100,rotation:0,align:'left'};let o;
    if(block.runs){const runs=block.runs.map(r=>({...r,font:r.font||'system',size:block.type==='heading'?28:r.size||17,bold:block.type==='heading'||r.bold}));const text=runs.map(r=>r.text).join('');o={...base,type:'text',runs,h:Math.max(70,(text.split('\n').length+Math.ceil(text.length/55))*31)};}
    else if(block.type==='table'){const count=Math.max(...block.rows.map(r=>r.length));const cols=Array(count).fill(900/count);o={...base,type:'table',cells:block.rows.map(row=>Array.from({length:count},(_,i)=>({runs:plain(row[i]||''),align:'left'}))),cols,rows:block.rows.map(()=>60),h:block.rows.length*60,header:true,borderColor:'#b8c3d5'};}
    else if(block.type==='chart')o={...base,...block,type:'chart',chartType:'bar',color:'#508de0',h:Math.max(220,block.values.length*50)};
    else if(block.type==='image')o={...base,...block,w:600,h:360,crop:{left:0,top:0,right:0,bottom:0},border:'none',radius:0,feather:0};
    else if(block.type==='file')o={...base,...block,h:90};
    if(o){objects.push(o);y+=o.h+24;}
  }
  if(!objects.length)objects.push({id:uid(),type:'text',x:50,y:50,w:900,h:100,rotation:0,align:'left',runs:plain('在这里写下你的理解…',20)});
  return {height:Math.max(350,y+30),objects};
}
function legacyBlocks(layout){const ordered=[],seen=new Set(),objects=new Map(layout.objects.map(o=>[o.id,o]));const visit=ref=>{if(!ref.startsWith('object:'))return;const o=objects.get(ref.slice(7));if(!o||seen.has(o.id))return;seen.add(o.id);ordered.push(o);for(const child of layout.flow?.['section:'+o.id]||[])visit(child);};for(const ref of layout.flow?.root||[])visit(ref);for(const o of layout.objects)visit('object:'+o.id);return ordered.map(o=>{
  if(o.type==='text')return {type:'paragraph',runs:o.runs};
  if(o.type==='section')return {type:'paragraph',runs:[...plain(o.title+'\n',24),...o.runs]};
  if(o.type==='table')return {type:'table',rows:o.cells.map(row=>row.map(cell=>cell.runs.map(r=>r.text).join('')))};
  if(o.type==='chart')return {type:'chart',title:o.title,values:o.values};
  return {type:o.type,url:o.url,name:o.name,caption:o.caption||''};
});}
async function openDocument(options){
  if(docSession?.dirty&&!(await saveDocument()))return;
  if(pageSession?.dirty&&!(await savePage()))return;
  if(!pageSession){editingPaused=false;enterPage();}
  options.opened?.();
  if(docSession){docSession.surface.destroy();docSession.dialog.remove();}
  const node=copy(config.getSite().nodes.find(n=>n.id===options.node.id)||options.node),layout=copy(node.design||legacyLayout(node));
  docSession={kind:'document',node,layout,options,dirty:!config.getSite().nodes.some(n=>n.id===node.id),history:[],future:[]};
  mountInlineDocument(docSession);docSession.dialog.scrollIntoView({behavior:'smooth',block:'start'});
  status('条目已在当前页面展开，直接点击正文即可修改。');
}
function mountInlineDocument(ctx){
  const section=document.createElement('section');section.className='st-inline-document';section.setAttribute('aria-label','当前页面中的条目内容');ctx.dialog=section;
  const node=ctx.node;
  section.innerHTML=`<header class="st-inline-heading"><div><span class="st-inline-kicker">${views[node.map]} · 内容编辑</span><h2 contenteditable="true" data-node-title role="textbox" aria-label="条目名称">${esc(node.title)}</h2><p contenteditable="true" data-node-summary role="textbox" aria-label="一句话解释">${esc(node.summary)}</p></div><button class="st-inline-collapse" type="button">收起条目 ↑</button></header><div class="st-inline-content"></div><p class="st-error" role="status"></p><details class="st-node-meta"><summary>条目属性、来源与关联</summary><div class="st-inline-meta-grid"><label>所属地图<select data-node-field="map">${['domain','ecology','cognition'].map(k=>`<option value="${k}" ${node.map===k?'selected':''}>${views[k]}</option>`).join('')}</select></label>${[['category','分类'],['status','学习 / 核实状态'],['kind','内容性质']].map(([k,t])=>`<label>${t}<input data-node-field="${k}" value="${esc(node[k])}" maxlength="80"></label>`).join('')}<label>当前理解与尚存问题<textarea data-node-field="question" maxlength="2000">${esc(node.question)}</textarea></label><label>来源（标题 | 链接 | 说明）<textarea data-sources>${esc(node.sources.map(s=>[s.title,s.url,s.note].join(' | ')).join('\n'))}</textarea></label><label>跨地图关联（ID | 关系）<textarea data-links>${esc(node.links.map(l=>l.id+' | '+l.reason).join('\n'))}</textarea></label></div><p>${ctx.options.nodes.filter(n=>n.id!==node.id).map(n=>esc(n.id)+'：'+esc(n.title)).join('； ')}</p></details>`;
  const host=$('#main .workspace')||$('#main .section')||$('#main');host.prepend(section);
  ctx.surface=new FlowSurface($('.st-inline-content',section),ctx.layout,true,changed,'document');active=ctx.surface;
  $('[data-node-title]',section).oninput=event=>{ctx.node.title=event.target.innerText;ctx.dirty=true;updateStatus();};
  $('[data-node-summary]',section).oninput=event=>{ctx.node.summary=event.target.innerText;ctx.dirty=true;updateStatus();};
  $$('[data-node-field]',section).forEach(input=>input.oninput=()=>{ctx.node[input.dataset.nodeField]=input.value;ctx.dirty=true;updateStatus();});
  $('[data-sources]',section).oninput=event=>{ctx.node.sources=event.target.value.split('\n').filter(v=>v.trim()).map(line=>{const [title,url='',...note]=line.split('|').map(v=>v.trim());return {title,url,note:note.join(' | ')};});ctx.dirty=true;updateStatus();};
  $('[data-links]',section).oninput=event=>{ctx.node.links=event.target.value.split('\n').filter(v=>v.trim()).map(line=>{const [id,...reason]=line.split('|').map(v=>v.trim());return {id,reason:reason.join(' | ')};});ctx.dirty=true;updateStatus();};
  $('.st-inline-collapse',section).onclick=closeDocument;
  $('.st-inline-content',section).addEventListener('pointerdown',event=>{const rect=ctx.surface.host.getBoundingClientRect();ctx.surface.anchor={x:clamp((event.clientX-rect.left)/ctx.surface.scale,24,976),y:Math.max(24,(event.clientY-rect.top)/ctx.surface.scale)};});
  section.addEventListener('focusin',()=>{active=ctx.surface;});renderInspector();updateStatus();
}
async function saveDocument(){
  if(!docSession)return true;const ctx=docSession;ctx.surface.captureAll();const node=copy(ctx.node);if(!node.title.trim()||!node.summary.trim()){status('请填写条目名称和一句话解释。');return false;}node.design=copy(ctx.layout);node.blocks=legacyBlocks(ctx.layout);
  const button=$('#studioDock [data-st="save"]');if(button)button.disabled=true;
  try{const result=await ctx.options.save(node);Object.assign(ctx.node,copy(result||node));ctx.dirty=false;if(pageSession)pageSession.revision=config.getSite().revision;$('.st-error',ctx.dialog).textContent='';updateStatus();status('条目内容与排版已保存。');return true;}catch(error){$('.st-error',ctx.dialog).textContent=error.message;status(error.message);return false;}finally{if(button)button.disabled=false;}
}
function closeDocument(){
  if(!docSession)return;if(docSession.dirty&&!confirm('条目有未保存的修改，确定放弃并收起吗？'))return;
  const ctx=docSession;ctx.surface.destroy();ctx.dialog.remove();docSession=null;active=pageSurface;selection=null;textTarget=null;renderInspector();updateStatus();pageSurface?.geometry();
}

document.addEventListener('selectionchange',preserveSelection);
document.addEventListener('keyup',()=>{if(document.activeElement?.closest('[contenteditable]')){selectionLocked=false;preserveSelection();}});
document.addEventListener('pointerup',event=>{if(event.target.closest('[contenteditable]')){selectionLocked=false;preserveSelection();}});
window.addEventListener('beforeunload',event=>{if(pageSession?.dirty||docSession?.dirty){event.preventDefault();event.returnValue='';}});
document.addEventListener('keydown',event=>{
  if((pageSession||docSession)&&(event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='s'){event.preventDefault();saveAll();}
  if((pageSession||docSession)&&event.key==='Delete'&&!event.target.closest('input,textarea,[contenteditable]')){event.preventDefault();active?.command('remove');}
});
document.addEventListener('click',event=>{if(pageSession&&event.target.closest('#main [data-st-text-key]')&&!event.target.closest('.st-inline-document,.st-layer')){event.preventDefault();event.stopPropagation();}},true);
window.AtlasStudio={configure:options=>{config=options;},page,refreshCards,openDocument,documentHTML:designHTML,fitViews,interceptClick:event=>{if(!pageSession||!event.target.closest('#main')||event.target.closest('.st-layer,.fm-custom,.fm-tools,.st-inline-document,[data-action="atlas"],[data-action="new-node"],[data-action="settings"],[data-action="export-feedback"]'))return false;const card=event.target.closest('.node-card');if(card&&!event.target.closest('[data-st-text-key]'))config.openInline?.(card.dataset.id);event.preventDefault();return true;},hasUnsaved:()=>!!(pageSession?.dirty||docSession?.dirty)};
})();
