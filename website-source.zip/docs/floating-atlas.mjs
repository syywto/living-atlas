import {virtualMapSVG} from './virtual-map.mjs';
export const HOVER_DELAY=800;
const MAPS=['domain','ecology','cognition'];
const escapeHTML=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));

export function buildAtlas(nodes){
  const valid=nodes.filter(n=>MAPS.includes(n.map));
  const rings=Math.max(1,...MAPS.map(map=>Math.ceil(valid.filter(n=>n.map===map).length/8)));
  const width=1800+(rings-1)*500,height=860+(rings-1)*360;
  const centers={domain:{x:width*.245,y:height*.31},ecology:{x:width*.755,y:height*.31},cognition:{x:width*.5,y:height*.70}};
  const points=new Map(),hubs=MAPS.map(map=>({id:map,...centers[map],nodes:valid.filter(n=>n.map===map)}));
  for(const hub of hubs){
    hub.nodes.forEach((node,index)=>{
      const ring=Math.floor(index/8),count=Math.min(8,hub.nodes.length-ring*8),angle=(-150+(index%8)*360/count)*Math.PI/180,radius=205+ring*115;
      points.set(node.id,{id:node.id,map:node.map,x:hub.x+Math.cos(angle)*radius,y:hub.y+Math.sin(angle)*radius,node});
    });
  }
  const edges=new Map(),seen=new Set();
  for(const n of valid)for(const link of n.links||[]){
    if(n.id===link.id||!points.has(link.id)||seen.has(n.id+'\0'+link.id))continue;
    seen.add(n.id+'\0'+link.id);const key=[n.id,link.id].sort().join('\0');
    if(!edges.has(key))edges.set(key,{a:points.get(n.id),b:points.get(link.id),relations:[]});
    edges.get(key).relations.push({from:n.id,to:link.id,reason:link.reason});
  }
  return {width,height,hubs,points,edges:[...edges.values()],relationCount:seen.size};
}

// Keep the delay independent from animation and pointer frequency.
export function createHoverIntent({show,hide,highlight},timers=globalThis){
  let pending=null,closing=null,key=null,disposed=false,shown=false;
  const clear=()=>{timers.clearTimeout(pending);timers.clearTimeout(closing);pending=closing=null;};
  return {
    enter(id,immediate=false){
      if(disposed)return;timers.clearTimeout(closing);closing=null;
      if(key===id&&(pending!==null||shown)&&!immediate)return;
      timers.clearTimeout(pending);if(key!==id){hide();shown=false;}key=id;highlight(id);
      if(immediate){pending=null;shown=true;show(id);}else pending=timers.setTimeout(()=>{pending=null;if(!disposed&&key===id){shown=true;show(id);}},HOVER_DELAY);
    },
    keep(){timers.clearTimeout(closing);closing=null;},
    leave(){
      timers.clearTimeout(pending);pending=null;timers.clearTimeout(closing);
      closing=timers.setTimeout(()=>{key=null;shown=false;hide();highlight(null);},140);
    },
    clear(){clear();key=null;shown=false;hide();highlight(null);},
    destroy(){disposed=true;clear();key=null;}
  };
}

function curve(a,b,index){
  const dx=b.x-a.x,dy=b.y-a.y,length=Math.max(1,Math.hypot(dx,dy)),bend=(a.map===b.map?34:60)*(index%2?1:-1);
  return `M${a.x},${a.y} Q${(a.x+b.x)/2-dy/length*bend},${(a.y+b.y)/2+dx/length*bend} ${b.x},${b.y}`;
}
const icons={
 domain:'<path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3Z"/><path d="M9 3v15m6-12v15"/>',
 ecology:'<circle cx="12" cy="12" r="3"/><ellipse cx="12" cy="12" rx="10" ry="5" transform="rotate(-28 12 12)"/><circle cx="4" cy="17" r="1.5"/><circle cx="20" cy="7" r="1.5"/>',
 cognition:'<path d="m12 2 3 7 7 3-7 3-3 7-3-7-7-3 7-3Z"/><circle cx="12" cy="12" r="2"/>'
};
const icon=map=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[map]}</svg>`;

export function mountAtlas(host,site,options){
  const {maps}=options,model=buildAtlas(site.nodes),esc=escapeHTML;
  const events=new AbortController(),on=(el,type,fn,extra={})=>el.addEventListener(type,fn,{...extra,signal:events.signal});
  let camera={x:0,y:0,scale:1},size={width:0,height:0},frame=0,visiblePreview=null,disposed=false,ignoreClickUntil=0,previewPinned=!!options.suspendHoverUntilMove;
  let moved=!!options.camera,pinch=null,drag=null,longPress=null,touchStart=null,longPressed=false;
  const pointers=new Map();
  const buttonPositions=[...model.points.values()];
  host.innerHTML=`<div class="fa-shell"><header class="fa-header"><div class="fa-heading"><span class="fa-mark" aria-hidden="true">${icon('domain')}</span><div><p>THE LIVING ATLAS</p><h1 id="atlasTitle">三张地图，一眼相连。</h1></div></div><div class="fa-header-stats"><span>03 张地图</span><span>${model.points.size} 个内容浮标</span><span>${model.relationCount} 条有向关联</span></div><button type="button" class="fa-icon-button fa-close" data-fa-close aria-label="关闭全景地图" title="关闭（Esc）">×</button></header><div class="fa-toolbar"><div class="fa-jumps" role="group" aria-label="定位三张地图"><button type="button" class="is-current" data-fa-jump="all">全图</button>${model.hubs.map(h=>`<button type="button" data-fa-jump="${h.id}"><i style="--fa-color:${maps[h.id].color}"></i>${maps[h.id].name}</button>`).join('')}</div><div class="fa-search"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.4" aria-hidden="true"><circle cx="8.5" cy="8.5" r="5.5"/><path d="m13 13 4 4"/></svg><input type="search" aria-label="定位地图中的内容浮标" placeholder="寻找一个概念或问题" autocomplete="off" maxlength="150" aria-controls="atlasSearchResults"><div id="atlasSearchResults" class="fa-search-results" hidden></div></div></div><div class="fa-stage" tabindex="0" role="region" aria-label="可拖动和缩放的三张地图。Tab 选择浮标，停留 0.8 秒预览，回车打开内容。"><div class="fa-world" style="width:${model.width}px;height:${model.height}px">${virtualMapSVG({id:'fa-fictional-world',width:model.width,height:model.height,className:'fa-terrain vm-map'})}${model.hubs.map(h=>`<div class="fa-region-glow" style="left:${h.x}px;top:${h.y}px;--fa-color:${maps[h.id].color}"></div>`).join('')}<svg class="fa-connections" width="${model.width}" height="${model.height}" aria-hidden="true"><g class="fa-memberships">${model.hubs.map(h=>h.nodes.map(n=>{const pt=model.points.get(n.id);return `<path d="M${h.x} ${h.y}L${pt.x} ${pt.y}" style="stroke:${maps[h.id].color}"/>`;}).join('')).join('')}</g><g class="fa-edges">${model.edges.map((e,i)=>`<g class="fa-edge" data-fa-edge="${i}" style="--fa-color:${maps[e.a.map].color}"><path class="fa-edge-line" d="${curve(e.a,e.b,i)}"/><path class="fa-edge-signal" d="${curve(e.a,e.b,i)}"/></g>`).join('')}</g>${model.hubs.map(h=>`<ellipse class="fa-orbit" cx="${h.x}" cy="${h.y}" rx="${216+(model.width-1800)*.23}" ry="${216+(model.width-1800)*.23}" style="stroke:${maps[h.id].color}"/>`).join('')}</svg>${model.hubs.map((h,i)=>`<div class="fa-marker-position fa-hub-position" style="left:${h.x}px;top:${h.y}px;--fa-color:${maps[h.id].color};--fa-phase:${-i*1.7}s"><span class="fa-hub-floor" aria-hidden="true"></span><button type="button" class="fa-hub" data-fa-marker="${h.id}" aria-label="进入${maps[h.id].name}，${h.nodes.length}个条目"><span class="fa-hub-orbit" aria-hidden="true"></span><span class="fa-hub-disc">${icon(h.id)}</span><strong>${maps[h.id].name}</strong><small>${String(h.nodes.length).padStart(2,'0')} 个条目 · 进入地图 ↗</small></button></div>`).join('')}${buttonPositions.map((pt,i)=>`<div class="fa-marker-position fa-node-position" style="left:${pt.x}px;top:${pt.y}px;--fa-color:${maps[pt.map].color};--fa-phase:${-(i%7)*.9}s"><button type="button" class="fa-node" data-fa-marker="${esc(pt.id)}" aria-label="打开${esc(pt.node.title)}"><span class="fa-node-dot" aria-hidden="true"></span><span class="fa-node-copy"><small>${esc(pt.node.category)}</small><strong>${esc(pt.node.title)}</strong></span><span class="fa-node-arrow" aria-hidden="true">↗</span></button><span class="fa-node-floor" aria-hidden="true"></span></div>`).join('')}</div><div class="fa-preview" id="atlasPreview" role="region" aria-label="浮标内容预览" hidden></div><div class="fa-zoom" role="group" aria-label="地图缩放"><button type="button" data-fa-zoom="in" aria-label="放大地图">＋</button><span class="fa-zoom-value" aria-live="off">100%</span><button type="button" data-fa-zoom="out" aria-label="缩小地图">−</button><span class="fa-control-divider"></span><button type="button" data-fa-fit aria-label="适应全图" title="适应全图">⛶</button></div><div class="fa-compass" aria-hidden="true"><span>N</span><svg viewBox="0 0 40 40"><path d="m20 5 6 25-6-6-6 6Z" fill="none" stroke="currentColor" stroke-width="1"/><circle cx="20" cy="20" r="18" fill="none" stroke="currentColor" stroke-opacity=".2"/></svg></div><div class="fa-caption"><span class="fa-caption-pulse" aria-hidden="true"></span><span class="fa-desktop-help">拖动探索 · Ctrl / ⌘ + 滚轮缩放 · 悬停 0.8 秒预览</span><span class="fa-touch-help">拖动探索 · 双指缩放 · 长按浮标预览</span></div></div><footer class="fa-footer"><span>连线表示条目间已记录的关联，可在预览中查看理由。</span><span>悬停时突出直接关联 · 双向关系合并为一条线 <span aria-hidden="true">↗</span></span></footer><span class="fa-announcer" role="status" aria-live="polite"></span></div>`;
  const $=selector=>host.querySelector(selector),$$=selector=>[...host.querySelectorAll(selector)];
  const stage=$('.fa-stage'),world=$('.fa-world'),preview=$('.fa-preview'),search=$('.fa-search input'),results=$('.fa-search-results');
  const markers=new Map($$('[data-fa-marker]').map(b=>[b.dataset.faMarker,b]));
  const point=id=>model.points.get(id)||model.hubs.find(h=>h.id===id);
  const edgeElements=$$('[data-fa-edge]');

  function highlight(id){
    const related=new Set(id?[id]:[]),hub=model.hubs.find(h=>h.id===id);
    for(let i=0;i<model.edges.length;i++){
      const e=model.edges[i],active=!!id&&(hub?(e.a.map===id||e.b.map===id):(e.a.id===id||e.b.id===id));
      edgeElements[i].classList.toggle('is-active',active);
      if(active){related.add(e.a.id);related.add(e.b.id);}
    }
    if(hub)hub.nodes.forEach(n=>related.add(n.id));
    host.classList.toggle('fa-has-active',!!id);
    for(const [key,el]of markers){el.classList.toggle('is-selected',key===id);el.classList.toggle('is-related',related.has(key));}
  }
  function positionPreview(){
    if(preview.hidden||!visiblePreview)return;
    const button=markers.get(visiblePreview),r=button?.getBoundingClientRect(),s=stage.getBoundingClientRect();if(!r)return;
    const width=Math.min(360,size.width-24);preview.style.width=width+'px';
    const height=preview.offsetHeight,maxX=Math.max(12,size.width-width-12),maxY=Math.max(12,size.height-height-12);
    let x=r.right-s.left+16,y=r.top-s.top-8;
    if(x+width>size.width-12)x=r.left-s.left-width-16;
    preview.style.left=clamp(x,12,maxX)+'px';preview.style.top=clamp(y,12,maxY)+'px';
  }
  function showPreview(id){
    const hub=model.hubs.find(h=>h.id===id),n=model.points.get(id)?.node;if(!hub&&!n)return;
    visiblePreview=id;const map=hub?id:n.map;
    const related=hub?[]:model.edges.filter(e=>e.a.id===id||e.b.id===id).map(e=>({id:e.a.id===id?e.b.id:e.a.id,relations:e.relations})).slice(0,3);
    const excerpt=n?.blocks?.find(b=>b.type==='paragraph')?.runs?.map(r=>r.text).join('')||'';
    preview.innerHTML=`<div class="fa-preview-heading" style="--fa-color:${maps[map].color}"><span>${maps[map].en} / ${hub?'地图':'内容'}预览</span><button type="button" data-fa-preview-close aria-label="关闭浮标预览">×</button></div><h2>${esc(hub?maps[map].name:n.title)}</h2><p>${esc(hub?maps[map].description:n.summary)}</p>${hub?`<div class="fa-preview-meta">${hub.nodes.length} 个条目 · 点击主浮标进入原地图页面</div>`:`<div class="fa-preview-meta">${esc(n.category)} <span>·</span> ${esc(n.status)}</div>${excerpt?`<p class="fa-preview-excerpt">${esc(excerpt.length>160?excerpt.slice(0,160)+'…':excerpt)}</p>`:''}${related.length?`<div class="fa-preview-relations"><h3>沿着这些关系继续</h3>${related.map(r=>{const target=point(r.id),outgoing=r.relations.some(l=>l.from===id),incoming=r.relations.some(l=>l.to===id),arrow=outgoing&&incoming?'↔':outgoing?'→':'←',reason=r.relations.map(l=>(l.from===id?'→ ':'← ')+l.reason).join('；');return `<button type="button" data-fa-related="${esc(target.id)}"><strong>${arrow} ${esc(target.node.title)}</strong><small>${esc(reason)}</small></button>`;}).join('')}</div>`:''}`}<button type="button" class="fa-preview-open" data-fa-open="${esc(id)}">${hub?'进入这张地图':'阅读完整内容'} <span aria-hidden="true">↗</span></button>`;
    preview.hidden=false;markers.get(id)?.setAttribute('aria-describedby','atlasPreview');positionPreview();
    $('.fa-announcer').textContent=(hub?maps[map].name:n.title)+'，内容预览已展开。';
  }
  function hidePreview(){if(visiblePreview)markers.get(visiblePreview)?.removeAttribute('aria-describedby');preview.hidden=true;visiblePreview=null;}
  const intent=createHoverIntent({show:showPreview,hide:hidePreview,highlight});
  function reveal(id){intent.enter(id,true);previewPinned=true;}

  function paint(){
    frame=0;if(disposed)return;
    world.style.transform=`translate3d(${camera.x}px,${camera.y}px,0) scale(${camera.scale})`;
    $('.fa-zoom-value').textContent=Math.round(camera.scale*100)+'%';positionPreview();
  }
  function schedule(){if(!frame)frame=requestAnimationFrame(paint);}
  function setCamera(next){camera={...next,scale:clamp(next.scale,.15,1.8)};schedule();}
  function focusAt(target,scale){moved=true;previewPinned=false;intent.clear();setCamera({scale,x:size.width/2-target.x*scale,y:size.height/2-target.y*scale});}
  function fit(){moved=false;intent.clear();const scale=clamp(Math.min((size.width-64)/model.width,(size.height-50)/model.height),.15,1.15);setCamera({scale,x:(size.width-model.width*scale)/2,y:(size.height-model.height*scale)/2});setJump('all');}
  function setJump(id){$$('[data-fa-jump]').forEach(b=>{const active=b.dataset.faJump===id;b.classList.toggle('is-current',active);b.setAttribute('aria-pressed',String(active));});}
  function zoom(factor,anchor={x:size.width/2,y:size.height/2}){
    moved=true;const scale=clamp(camera.scale*factor,.15,1.8),ratio=scale/camera.scale;
    setCamera({scale,x:anchor.x-(anchor.x-camera.x)*ratio,y:anchor.y-(anchor.y-camera.y)*ratio});
  }
  function open(id){intent.clear();if(MAPS.includes(id))options.openMap(id);else options.openNode(id);}

  for(const [id,button]of markers){
    on(button,'pointerenter',e=>{if(e.pointerType!=='touch'&&!drag&&!previewPinned)intent.enter(id);});
    on(button,'pointerleave',()=>{if(!drag&&!previewPinned)intent.leave();});
    on(button,'focus',()=>{previewPinned=false;intent.enter(id);});
    on(button,'blur',e=>{if(!preview.contains(e.relatedTarget))intent.leave();});
    on(button,'click',event=>{event.stopPropagation();if(performance.now()<ignoreClickUntil){event.preventDefault();return;}open(id);});
  }
  on(preview,'pointerenter',()=>intent.keep());on(preview,'pointerleave',()=>intent.leave());
  on(preview,'focusin',()=>intent.keep());on(preview,'focusout',e=>{if(!preview.contains(e.relatedTarget))intent.leave();});
  on(preview,'click',event=>{
    event.stopPropagation();const close=event.target.closest('[data-fa-preview-close]'),read=event.target.closest('[data-fa-open]'),related=event.target.closest('[data-fa-related]');
    if(close){const current=visiblePreview;intent.clear();markers.get(current)?.focus({preventScroll:true});intent.clear();}
    if(read)open(read.dataset.faOpen);
    if(related){const id=related.dataset.faRelated;focusAt(point(id),Math.max(camera.scale,.85));reveal(id);}
  });
  on($('[data-fa-close]'),'click',options.close);
  $$('[data-fa-jump]').forEach(button=>on(button,'click',()=>{const id=button.dataset.faJump;if(id==='all')fit();else{setJump(id);focusAt(point(id),clamp(Math.min(size.width/600,size.height/570),.58,1.25));}}));
  $$('[data-fa-zoom]').forEach(button=>on(button,'click',()=>{intent.clear();zoom(button.dataset.faZoom==='in'?1.2:1/1.2);}));
  on($('[data-fa-fit]'),'click',fit);
  on(stage,'wheel',event=>{if(!(event.ctrlKey||event.metaKey))return;event.preventDefault();intent.clear();const r=stage.getBoundingClientRect();zoom(Math.exp(-event.deltaY*.004),{x:event.clientX-r.left,y:event.clientY-r.top});},{passive:false});
  on(stage,'keydown',event=>{
    if(event.key==='Escape'&&!preview.hidden){event.preventDefault();event.stopPropagation();intent.clear();return;}
    if(event.target!==stage)return;
    if(['+','=','-','0','ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key)){
      event.preventDefault();intent.clear();if(event.key==='0')fit();else if(['+','=','-'].includes(event.key))zoom(event.key==='-'?1/1.2:1.2);else{moved=true;camera.x+=event.key==='ArrowRight'?-55:event.key==='ArrowLeft'?55:0;camera.y+=event.key==='ArrowDown'?-55:event.key==='ArrowUp'?55:0;schedule();}
    }
  });
  function cancelLongPress(){clearTimeout(longPress);longPress=null;}
  function coords(e){const r=stage.getBoundingClientRect();return {x:e.clientX-r.left,y:e.clientY-r.top};}
  on(stage,'pointerdown',event=>{
    if(event.button!==0||event.target.closest('.fa-preview,.fa-zoom'))return;
    const marker=event.target.closest('[data-fa-marker]'),pos=coords(event);pointers.set(event.pointerId,pos);
    if(pointers.size===2){
      cancelLongPress();intent.clear();const [a,b]=[...pointers.values()],mid={x:(a.x+b.x)/2,y:(a.y+b.y)/2};pinch={distance:Math.hypot(a.x-b.x,a.y-b.y),camera:{...camera},mid};drag=null;
      event.preventDefault();return;
    }
    if(marker){if(event.pointerType!=='mouse'){touchStart={id:event.pointerId,marker:marker.dataset.faMarker,pos,camera:{...camera}};longPress=setTimeout(()=>{reveal(touchStart?.marker||marker.dataset.faMarker);longPressed=true;ignoreClickUntil=performance.now()+1000;},HOVER_DELAY);}return;}
    intent.clear();drag={id:event.pointerId,pos,camera:{...camera},distance:0};stage.classList.add('is-dragging');stage.setPointerCapture(event.pointerId);event.preventDefault();
  });
  on(stage,'pointermove',event=>{
    if(previewPinned&&!pointers.size&&(Math.abs(event.movementX)+Math.abs(event.movementY)>0)){previewPinned=false;const marker=event.target.closest('[data-fa-marker]');if(marker)intent.enter(marker.dataset.faMarker);else if(!event.target.closest('.fa-preview'))intent.leave();}
    if(!pointers.has(event.pointerId))return;const pos=coords(event);pointers.set(event.pointerId,pos);
    if(pinch&&pointers.size===2){
      const [a,b]=[...pointers.values()],mid={x:(a.x+b.x)/2,y:(a.y+b.y)/2},scale=clamp(pinch.camera.scale*Math.hypot(a.x-b.x,a.y-b.y)/Math.max(pinch.distance,1),.15,1.8),ratio=scale/pinch.camera.scale;
      moved=true;setCamera({scale,x:mid.x-(pinch.mid.x-pinch.camera.x)*ratio,y:mid.y-(pinch.mid.y-pinch.camera.y)*ratio});ignoreClickUntil=performance.now()+500;return;
    }
    if(touchStart&&touchStart.id===event.pointerId&&Math.hypot(pos.x-touchStart.pos.x,pos.y-touchStart.pos.y)>7){cancelLongPress();intent.clear();drag={id:event.pointerId,pos:touchStart.pos,camera:touchStart.camera,distance:8};touchStart=null;stage.setPointerCapture(event.pointerId);stage.classList.add('is-dragging');}
    if(drag?.id===event.pointerId){const dx=pos.x-drag.pos.x,dy=pos.y-drag.pos.y;drag.distance=Math.hypot(dx,dy);moved=true;camera={...drag.camera,x:drag.camera.x+dx,y:drag.camera.y+dy};schedule();event.preventDefault();}
  });
  function release(event){
    pointers.delete(event.pointerId);cancelLongPress();touchStart=null;if(drag?.distance>5||pinch||longPressed)ignoreClickUntil=performance.now()+500;longPressed=false;
    if(pointers.size<2)pinch=null;drag=null;stage.classList.remove('is-dragging');if(stage.hasPointerCapture(event.pointerId))stage.releasePointerCapture(event.pointerId);
  }
  on(stage,'pointerup',release);on(stage,'pointercancel',release);on(stage,'lostpointercapture',()=>{drag=null;stage.classList.remove('is-dragging');});
  on(stage,'click',event=>{if(performance.now()<ignoreClickUntil){event.preventDefault();event.stopImmediatePropagation();ignoreClickUntil=0;}},{capture:true});
  on(stage,'click',event=>{if(event.target===stage||event.target.closest('.fa-terrain,.fa-connections'))intent.clear();});

  on(search,'input',()=>{
    const q=search.value.trim().toLocaleLowerCase(),matches=q?buttonPositions.filter(pt=>(pt.node.title+' '+pt.node.summary+' '+pt.node.category).toLocaleLowerCase().includes(q)):[];
    for(const pt of buttonPositions)markers.get(pt.id).classList.toggle('is-search-match',matches.some(m=>m.id===pt.id));
    results.hidden=!q;results.innerHTML=matches.length?matches.slice(0,6).map(pt=>`<button type="button" data-fa-search-result="${esc(pt.id)}"><span style="--fa-color:${maps[pt.map].color}"></span><strong>${esc(pt.node.title)}</strong><small>${maps[pt.map].name}</small></button>`).join(''):'<p>没有找到相关浮标，试试“图像”“OCR”或“课程”。</p>';
  });
  on(search,'keydown',event=>{if(event.key==='ArrowDown'){event.preventDefault();results.querySelector('button')?.focus();}if(event.key==='Escape'){results.hidden=true;event.stopPropagation();}});
  on(results,'click',event=>{const b=event.target.closest('[data-fa-search-result]');if(!b)return;const id=b.dataset.faSearchResult;results.hidden=true;focusAt(point(id),Math.max(camera.scale,.95));markers.get(id).focus({preventScroll:true});reveal(id);});
  on(host,'click',event=>{if(!event.target.closest('.fa-search'))results.hidden=true;});
  on(results,'keydown',event=>{if(event.key==='Escape'){results.hidden=true;search.focus();event.stopPropagation();}});

  const observer=new ResizeObserver(()=>{
    const next={width:stage.clientWidth,height:stage.clientHeight};if(!next.width||!next.height)return;
    if(!size.width){size=next;if(options.camera){camera={...options.camera};schedule();}else if(size.width<650){focusAt(point('domain'),.72);setJump('domain');}else fit();
      if(options.focusId&&point(options.focusId)){focusAt(point(options.focusId),Math.max(camera.scale,.8));reveal(options.focusId);}
    }else{const old=size;size=next;if(!moved)fit();else{camera.x+=(size.width-old.width)/2;camera.y+=(size.height-old.height)/2;schedule();}}
  });observer.observe(stage);
  return {
    getCamera:()=>({...camera}),
    destroy(){disposed=true;intent.destroy();events.abort();observer.disconnect();cancelAnimationFrame(frame);cancelLongPress();pointers.clear();}
  };
}
