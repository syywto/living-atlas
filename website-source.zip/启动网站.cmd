@echo off
setlocal
chcp 65001 >nul
title Living Atlas - Local Preview
cd /d "%~dp0"
set "ATLAS_NODE="
for /f "delims=" %%N in ('where.exe node.exe 2^>nul') do if not defined ATLAS_NODE set "ATLAS_NODE=%%N"
if not defined ATLAS_NODE if exist "%ProgramFiles%\nodejs\node.exe" set "ATLAS_NODE=%ProgramFiles%\nodejs\node.exe"
if not defined ATLAS_NODE if exist "D:\node.exe" set "ATLAS_NODE=D:\node.exe"
if not defined ATLAS_NODE if exist "%LOCALAPPDATA%\Programs\nodejs\node.exe" set "ATLAS_NODE=%LOCALAPPDATA%\Programs\nodejs\node.exe"
if not defined ATLAS_NODE if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" set "ATLAS_NODE=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe"
if not defined ATLAS_NODE goto missing_node
"%ATLAS_NODE%" "%~dp0scripts\start-local.mjs" %*
if errorlevel 1 echo ERROR: Startup failed. See the message above and .runtime\startup.log.
goto finish
:missing_node
echo ERROR: Node.js was not found.
echo Install Node.js 22 or newer from https://nodejs.org and try again.
:finish
echo.
echo Press any key to close this window.
pause >nul
endlocal
